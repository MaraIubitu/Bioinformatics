"""
Markov Chain State Prediction - Matrix-Vector Discrete Steps
This program implements state prediction over 5 discrete time steps
using a transition matrix and initial state vector.
"""

import numpy as np
import tkinter as tk
from tkinter import ttk, scrolledtext
import json

def predict_states(transition_matrix, initial_vector, num_steps=5):
    """
    Predict states over multiple discrete time steps.
    At each step: new_state = transition_matrix @ current_state
    
    Args:
        transition_matrix: Square matrix representing state transitions
        initial_vector: Initial state vector
        num_steps: Number of prediction steps
    
    Returns:
        List of state vectors for each step (including initial state)
    """
    states = [initial_vector]
    current_state = initial_vector.copy()
    
    for step in range(num_steps):
        # Matrix-vector multiplication
        next_state = transition_matrix @ current_state
        states.append(next_state)
        current_state = next_state
    
    return states

def format_matrix(matrix, title="Matrix"):
    """
    Format matrix as a string with proper alignment.
    """
    lines = [title, "=" * 60]
    n = len(matrix)
    
    for i in range(n):
        row_str = "  [ "
        for j in range(n):
            row_str += f"{matrix[i][j]:8.4f} "
        row_str += "]"
        lines.append(row_str)
    
    return "\n".join(lines)

def format_vector(vector, label="Vector"):
    """
    Format vector as a string.
    """
    lines = [f"{label}:"]
    for i, val in enumerate(vector):
        lines.append(f"  State {i+1}: {val:.6f}")
    return "\n".join(lines)

def save_results_to_json(matrix, initial_vector, states, filename="prediction_results.json"):
    """
    Save prediction results to JSON file.
    """
    data = {
        "transition_matrix": matrix.tolist(),
        "initial_vector": initial_vector.tolist(),
        "predictions": {
            f"step_{i}": state.tolist() for i, state in enumerate(states)
        },
        "num_steps": len(states) - 1,
        "matrix_size": len(matrix)
    }
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)
    
    return filename

def create_gui(matrix, initial_vector, states):
    """
    Create GUI to display prediction results.
    """
    root = tk.Tk()
    root.title("Markov Chain State Prediction - 5 Discrete Steps")
    root.geometry("900x700")
    
    # Create scrollable text widget
    text_frame = ttk.Frame(root)
    text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    result_text = scrolledtext.ScrolledText(text_frame, wrap=tk.WORD, 
                                            font=("Courier New", 10))
    result_text.pack(fill=tk.BOTH, expand=True)
    
    # Build output
    output = []
    output.append("=" * 80)
    output.append("MARKOV CHAIN STATE PREDICTION - 5 DISCRETE STEPS")
    output.append("=" * 80)
    output.append("")
    
    # Display transition matrix
    output.append("TRANSITION MATRIX (P)")
    output.append("=" * 80)
    n = len(matrix)
    for i in range(n):
        row_str = "  [ "
        for j in range(n):
            row_str += f"{matrix[i][j]:8.4f} "
        row_str += "]"
        output.append(row_str)
    output.append("")
    
    # Verify matrix properties
    output.append("MATRIX PROPERTIES:")
    output.append("-" * 80)
    output.append(f"  Size: {n}x{n}")
    
    # Check if rows sum to 1 (stochastic matrix)
    row_sums = [sum(matrix[i]) for i in range(n)]
    is_stochastic = all(abs(s - 1.0) < 1e-10 for s in row_sums)
    output.append(f"  Stochastic (rows sum to 1): {is_stochastic}")
    output.append("")
    
    # Display initial state
    output.append("INITIAL STATE VECTOR (Step 0)")
    output.append("=" * 80)
    for i, val in enumerate(initial_vector):
        output.append(f"  State {i+1}: {val:.6f}")
    output.append(f"  Sum: {sum(initial_vector):.6f}")
    output.append("")
    
    # Display predictions for each step
    for step_num in range(1, len(states)):
        output.append("=" * 80)
        output.append(f"PREDICTION - STEP {step_num}")
        output.append("=" * 80)
        output.append(f"Formula: State(t+1) = P  State(t)")
        output.append("")
        
        state = states[step_num]
        for i, val in enumerate(state):
            output.append(f"  State {i+1}: {val:.6f}")
        output.append(f"  Sum: {sum(state):.6f}")
        output.append("")
    
    # Summary
    output.append("=" * 80)
    output.append("SUMMARY OF ALL STEPS")
    output.append("=" * 80)
    header = f"Step      "
    for i in range(n):
        header += f"State {i+1:<10}"
    output.append(header)
    output.append("")
    output.append("-" * 80)
    
    for step_num, state in enumerate(states):
        row = f"{step_num:<10}"
        for val in state:
            row += f"{val:<15.6f}"
        output.append(row)
    
    output.append("")
    output.append("=" * 80)
    output.append("ANALYSIS COMPLETE")
    output.append("=" * 80)
    output.append("")
    output.append("Results saved to: prediction_results.json")
    
    # Insert text
    result_text.insert(tk.END, "\n".join(output))
    result_text.config(state=tk.DISABLED)
    
    root.mainloop()

def main():
    print("=" * 80)
    print("MARKOV CHAIN STATE PREDICTION - 5 DISCRETE STEPS")
    print("=" * 80)
    
    # Example 1: 3x3 Weather prediction matrix
    # States: Sunny, Cloudy, Rainy
    transition_matrix = np.array([
        [0.7, 0.2, 0.1],   # From Sunny to: Sunny, Cloudy, Rainy
        [0.3, 0.4, 0.3],   # From Cloudy to: Sunny, Cloudy, Rainy
        [0.2, 0.3, 0.5]    # From Rainy to: Sunny, Cloudy, Rainy
    ])
    
    # Initial state: Start with Sunny (100% probability in state 1)
    initial_vector = np.array([1.0, 0.0, 0.0])
    
    print("\nScenario: Weather Prediction Model")
    print("States: 1=Sunny, 2=Cloudy, 3=Rainy")
    print("-" * 80)
    
    print("\n" + format_matrix(transition_matrix, "TRANSITION MATRIX (P)"))
    print("\n" + format_vector(initial_vector, "INITIAL STATE (Day 0)"))
    
    # Perform 5-step prediction
    print("\n" + "=" * 80)
    print("PERFORMING 5-STEP PREDICTION")
    print("=" * 80)
    
    states = predict_states(transition_matrix, initial_vector, num_steps=5)
    
    # Display results
    for step_num in range(1, len(states)):
        print(f"\nStep {step_num} (Day {step_num}):")
        print("-" * 80)
        state = states[step_num]
        print(f"  Sunny:  {state[0]:.6f} ({state[0]*100:.2f}%)")
        print(f"  Cloudy: {state[1]:.6f} ({state[1]*100:.2f}%)")
        print(f"  Rainy:  {state[2]:.6f} ({state[2]*100:.2f}%)")
        print(f"  Sum:    {sum(state):.6f}")
    
    # Summary table
    print("\n" + "=" * 80)
    print("SUMMARY TABLE")
    print("=" * 80)
    print(f"{'Day':<8}{'Sunny':<15}{'Cloudy':<15}{'Rainy':<15}")
    print("-" * 80)
    for step_num, state in enumerate(states):
        print(f"{step_num:<8}{state[0]:<15.6f}{state[1]:<15.6f}{state[2]:<15.6f}")
    
    # Save to JSON
    json_file = save_results_to_json(transition_matrix, initial_vector, states)
    print("\n" + "=" * 80)
    print(f"Results saved to: {json_file}")
    print("=" * 80)
    
    # Launch GUI
    print("\nLaunching GUI window...")
    create_gui(transition_matrix, initial_vector, states)

if __name__ == "__main__":
    main()

