"""
DNA Transition Matrix Calculator
Calculates transition matrix from a 50-letter DNA sequence and saves to JSON
"""

import json
from collections import defaultdict

def count_transitions(sequence):
    """
    Count transition frequencies from one nucleotide to another in a sequence.
    Returns a dictionary with transition counts.
    """
    transitions = defaultdict(int)
    nucleotides = ['A', 'C', 'G', 'T']
    
    # Initialize all possible transitions to 0
    for n1 in nucleotides:
        for n2 in nucleotides:
            transitions[f"{n1}->{n2}"] = 0
    
    # Count transitions
    for i in range(len(sequence) - 1):
        current = sequence[i]
        next_nuc = sequence[i + 1]
        transitions[f"{current}->{next_nuc}"] += 1
    
    return transitions

def calculate_transition_probabilities(transitions, sequence):
    """
    Convert transition counts to probabilities.
    Returns a dictionary with transition probabilities.
    """
    probabilities = {}
    nucleotides = ['A', 'C', 'G', 'T']
    
    # Calculate total transitions from each nucleotide
    totals = defaultdict(int)
    for key, count in transitions.items():
        n1 = key.split('->')[0]
        totals[n1] += count
    
    # Calculate probabilities
    for n1 in nucleotides:
        for n2 in nucleotides:
            key = f"{n1}->{n2}"
            if totals[n1] > 0:
                probabilities[key] = transitions[key] / totals[n1]
            else:
                probabilities[key] = 0.0
    
    return probabilities

def print_matrix(data, title, is_count=False):
    """
    Print a matrix in a nice format.
    """
    nucleotides = ['A', 'C', 'G', 'T']
    print(f"\n{title}")
    print("=" * 60)
    
    # Header
    print(f"{'From/To':<10}", end="")
    for n in nucleotides:
        print(f"{n:>10}", end="")
    print()
    print("-" * 60)
    
    # Rows
    for n1 in nucleotides:
        print(f"{n1:<10}", end="")
        for n2 in nucleotides:
            key = f"{n1}->{n2}"
            value = data[key]
            if is_count:
                print(f"{value:>10}", end="")
            else:
                print(f"{value:>10.4f}", end="")
        print()
    print()

def save_to_json(sequence, transitions, probabilities, filename):
    """
    Save the transition matrix data to a JSON file.
    """
    data = {
        "sequence": sequence,
        "sequence_length": len(sequence),
        "transition_counts": transitions,
        "transition_probabilities": probabilities,
        "nucleotide_counts": {
            "A": sequence.count('A'),
            "C": sequence.count('C'),
            "G": sequence.count('G'),
            "T": sequence.count('T')
        }
    }
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)
    
    return data

def main():
    print("=" * 70)
    print("DNA TRANSITION MATRIX CALCULATOR")
    print("=" * 70)
    
    # 50-letter DNA sequence
    sequence = "ATCGATCGATCGTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTA"
    
    print(f"\nDNA Sequence ({len(sequence)} letters):")
    print(f"{sequence}")
    
    # Verify it's 50 letters
    if len(sequence) != 50:
        print(f"\nWarning: Sequence length is {len(sequence)}, not 50!")
        return
    
    # Count nucleotides
    print(f"\nNucleotide Composition:")
    for nuc in ['A', 'C', 'G', 'T']:
        count = sequence.count(nuc)
        percentage = (count / len(sequence)) * 100
        print(f"  {nuc}: {count} ({percentage:.1f}%)")
    
    # Count transitions
    print("\n" + "=" * 70)
    print("CALCULATING TRANSITION MATRIX")
    print("=" * 70)
    
    transitions = count_transitions(sequence)
    print_matrix(transitions, "Transition Counts", is_count=True)
    
    # Calculate probabilities
    probabilities = calculate_transition_probabilities(transitions, sequence)
    print_matrix(probabilities, "Transition Probabilities (Matrix)")
    
    # Save to JSON
    json_filename = "transition_matrix.json"
    print("=" * 70)
    print(f"SAVING TO JSON FILE: {json_filename}")
    print("=" * 70)
    
    data = save_to_json(sequence, transitions, probabilities, json_filename)
    
    print(f"\n✓ Successfully saved transition matrix to '{json_filename}'")
    print(f"\nJSON file contains:")
    print(f"  - Original sequence")
    print(f"  - Sequence length: {data['sequence_length']}")
    print(f"  - Transition counts (16 values)")
    print(f"  - Transition probabilities (16 values)")
    print(f"  - Nucleotide composition")
    
    print("\n" + "=" * 70)
    print("COMPLETE")
    print("=" * 70)

if __name__ == "__main__":
    main()
