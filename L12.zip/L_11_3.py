"""
Word Transition Probability Calculator
Calculates transition probabilities between words in English text (300 letters)
Each unique word is represented by a unique symbol
"""

import json
import re
from collections import defaultdict

def create_word_symbol_mapping(words):
    """
    Create a mapping of unique words to symbols.
    """
    unique_words = []
    seen = set()
    for word in words:
        if word not in seen:
            unique_words.append(word)
            seen.add(word)
    
    # Create symbol mapping (W1, W2, W3, etc.)
    word_to_symbol = {}
    symbol_to_word = {}
    
    for i, word in enumerate(unique_words, 1):
        symbol = f"W{i}"
        word_to_symbol[word] = symbol
        symbol_to_word[symbol] = word
    
    return word_to_symbol, symbol_to_word

def count_word_transitions(words, word_to_symbol):
    """
    Count transitions from one word to another.
    """
    transitions = defaultdict(int)
    
    # Count transitions
    for i in range(len(words) - 1):
        current_word = words[i]
        next_word = words[i + 1]
        current_symbol = word_to_symbol[current_word]
        next_symbol = word_to_symbol[next_word]
        
        transitions[f"{current_symbol}->{next_symbol}"] += 1
    
    return transitions

def calculate_word_transition_probabilities(transitions, word_to_symbol):
    """
    Convert transition counts to probabilities.
    """
    probabilities = {}
    
    # Calculate total transitions from each symbol
    totals = defaultdict(int)
    for key, count in transitions.items():
        symbol1 = key.split('->')[0]
        totals[symbol1] += count
    
    # Calculate probabilities
    for key, count in transitions.items():
        symbol1 = key.split('->')[0]
        if totals[symbol1] > 0:
            probabilities[key] = count / totals[symbol1]
        else:
            probabilities[key] = 0.0
    
    return probabilities

def extract_words(text):
    """
    Extract words from text (letters only, converted to lowercase).
    """
    # Remove punctuation and split into words
    words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
    return words

def save_to_json(text, words, word_to_symbol, symbol_to_word, transitions, probabilities, filename):
    """
    Save word transition data to JSON file.
    """
    # Convert transitions and probabilities to include word names for clarity
    transitions_with_words = {}
    probabilities_with_words = {}
    
    for key, value in transitions.items():
        symbols = key.split('->')
        s1, s2 = symbols[0], symbols[1]
        word_key = f"{symbol_to_word[s1]}->{symbol_to_word[s2]} ({key})"
        transitions_with_words[word_key] = value
    
    for key, value in probabilities.items():
        symbols = key.split('->')
        s1, s2 = symbols[0], symbols[1]
        word_key = f"{symbol_to_word[s1]}->{symbol_to_word[s2]} ({key})"
        probabilities_with_words[word_key] = value
    
    data = {
        "original_text": text,
        "text_length": len(text),
        "word_count": len(words),
        "unique_word_count": len(word_to_symbol),
        "word_to_symbol_mapping": word_to_symbol,
        "symbol_to_word_mapping": symbol_to_word,
        "word_sequence": [word_to_symbol[w] for w in words],
        "transition_counts": transitions_with_words,
        "transition_probabilities": probabilities_with_words
    }
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)
    
    return data

def main():
    print("=" * 80)
    print("WORD TRANSITION PROBABILITY CALCULATOR")
    print("=" * 80)
    
    # 300-letter English text
    text = """The sun was shining on the sea shining with all its might and this was odd 
because it was the middle of the night. The moon was shining sulkily because she 
thought the sun had got no business to be there after the day was done. The sea 
was wet as wet could be and the sands were dry."""
    
    # Ensure it's approximately 300 letters
    actual_length = len(text)
    print(f"\nOriginal Text ({actual_length} characters):")
    print("-" * 80)
    print(text)
    print("-" * 80)
    
    # Extract words
    words = extract_words(text)
    print(f"\nExtracted {len(words)} words from the text")
    print(f"Words: {' '.join(words[:20])}{'...' if len(words) > 20 else ''}")
    
    # Create word-to-symbol mapping
    word_to_symbol, symbol_to_word = create_word_symbol_mapping(words)
    
    print(f"\n{'=' * 80}")
    print(f"WORD TO SYMBOL MAPPING ({len(word_to_symbol)} unique words)")
    print("=" * 80)
    for word, symbol in sorted(word_to_symbol.items()):
        print(f"  {symbol}: '{word}'")
    
    # Show word sequence with symbols
    print(f"\n{'=' * 80}")
    print("TEXT AS SYMBOL SEQUENCE")
    print("=" * 80)
    symbol_sequence = [word_to_symbol[w] for w in words]
    # Display in chunks
    chunk_size = 15
    for i in range(0, len(symbol_sequence), chunk_size):
        chunk = symbol_sequence[i:i+chunk_size]
        print(f"  {' -> '.join(chunk)}")
    
    # Count transitions
    print(f"\n{'=' * 80}")
    print("CALCULATING WORD TRANSITIONS")
    print("=" * 80)
    
    transitions = count_word_transitions(words, word_to_symbol)
    probabilities = calculate_word_transition_probabilities(transitions, word_to_symbol)
    
    print(f"\nTotal unique transitions: {len(transitions)}")
    print(f"\nTop 10 Most Frequent Transitions:")
    sorted_transitions = sorted(transitions.items(), key=lambda x: x[1], reverse=True)[:10]
    for trans, count in sorted_transitions:
        symbols = trans.split('->')
        s1, s2 = symbols[0], symbols[1]
        word1, word2 = symbol_to_word[s1], symbol_to_word[s2]
        prob = probabilities[trans]
        print(f"  {word1} -> {word2} ({trans}): count={count}, probability={prob:.4f}")
    
    # Save to JSON
    json_filename = "word_transitions.json"
    print(f"\n{'=' * 80}")
    print(f"SAVING TO JSON FILE: {json_filename}")
    print("=" * 80)
    
    data = save_to_json(text, words, word_to_symbol, symbol_to_word, 
                        transitions, probabilities, json_filename)
    
    print(f"\n✓ Successfully saved word transition data to '{json_filename}'")
    print(f"\nJSON file contains:")
    print(f"  - Original text ({data['text_length']} characters)")
    print(f"  - Word count: {data['word_count']}")
    print(f"  - Unique words: {data['unique_word_count']}")
    print(f"  - Word-to-Symbol mapping")
    print(f"  - Symbol-to-Word mapping")
    print(f"  - Word sequence as symbols")
    print(f"  - Transition counts: {len(transitions)} unique transitions")
    print(f"  - Transition probabilities")
    
    print("\n" + "=" * 80)
    print("COMPLETE")
    print("=" * 80)
    print(f"\nFile location: C:\\Users\\Mara\\Desktop\\bioinfo\\{json_filename}")

if __name__ == "__main__":
    main()
