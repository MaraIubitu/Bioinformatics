﻿Transition Matrix and Markov Chain Projects - Lab 11
====================================================

Author(s):
----------
Iubitu Mara-Alexandra, 1241EA


Project Description:
-------------------
This collection contains three Python programs that demonstrate transition matrix
calculations and Markov Chain state predictions using different types of sequences.


Project Files:
-------------

1. L11_1.py - Markov Chain State Prediction (5 Discrete Steps)
   ----------------------------------------------------------
   - Implements state prediction over 5 discrete time steps
   - Uses a square transition matrix and initial state vector
   - Example: Weather prediction model (Sunny, Cloudy, Rainy)
   - Features:
     * Matrix-vector multiplication for each step
     * Probability distribution tracking
     * GUI window displaying all results in tables
     * JSON output: prediction_results.json
   
   How to run: python L11_1.py
   

2. L11_2.py - DNA Sequence Transition Matrix (50 Letters)
   -------------------------------------------------------
   - Calculates transition frequencies and probabilities for DNA sequences
   - Uses a 50-nucleotide DNA sequence
   - Counts all AC, AG, AT, CA, etc. transitions
   - Features:
     * Transition count matrix
     * Transition probability matrix
     * Nucleotide composition analysis
     * JSON output: transition_matrix.json
   
   How to run: python L11_2.py


3. L_11_3.py - Word Transition Probabilities (300 Letters)
   --------------------------------------------------------
   - Calculates transition probabilities between words in English text
   - Uses approximately 300-letter text passage
   - Assigns unique symbols to each word (W1, W2, W3, etc.)
   - Features:
     * Word-to-Symbol mapping
     * Symbol-to-Word reverse mapping
     * Word sequence as symbols
     * Transition counts and probabilities
     * JSON output: word_transitions.json
   
   How to run: python L_11_3.py


Output Files:
------------
- prediction_results.json    : Results from L11_1.py (Markov Chain predictions)
- transition_matrix.json     : Results from L11_2.py (DNA transitions)
- word_transitions.json      : Results from L_11_3.py (Word transitions)


Requirements:
------------
- Python 3.x
- numpy (for L11_1.py matrix operations)
- tkinter (for GUI windows)
- json (built-in)


Key Concepts Demonstrated:
--------------------------
1. Transition Matrices: Count and probability calculations
2. Markov Chains: State prediction using matrix multiplication
3. Discrete Time Steps: Iterative state evolution
4. Symbol Representation: Mapping text to mathematical symbols
5. Data Persistence: JSON file storage


Mathematical Formulas:
---------------------
- Transition Probability: P(ij) = Count(ij) / Total_from(i)
- Markov Chain: State(t+1) = P  State(t)
- Log-Likelihood (see L11.py): β = log(P/P)


Date: January 16, 2026
