# Lab 12: DNA Motif Finding - Splice Site Recognition

**Author:** Iubitu Mara, 1241EA

## Overview

This lab implements computational methods for discovering DNA motifs, specifically focusing on splice site recognition at exon-intron boundaries. The project builds position-specific scoring matrices (PSSMs) from known motif sequences and uses them to scan DNA sequences for potential splice sites - a crucial step in understanding gene structure and transcription.

## Background

### Splice Site Recognition

Splice sites mark the boundaries between exons (coding regions) and introns (non-coding regions) in eukaryotic genes. Recognizing these boundaries is essential for:
- **Gene annotation**: Identifying coding sequences
- **RNA splicing prediction**: Understanding how pre-mRNA is processed
- **Exon definition**: Early step in splice site recognition requiring communication between exon ends
- **Transcription factor binding site (TFBS) discovery**: Identifying regulatory elements

### The Challenge

Computational discovery of exon-intron borders is challenging due to:
- Sequence variability at splice sites
- Context-dependent recognition
- Balance between sensitivity and specificity
- Need for probabilistic models rather than exact matches

## Files

### ex1.py
Basic motif finding implementation analyzing a single test sequence.

**Features:**
- Constructs all four matrices from 9 known motif sequences
- Analyzes test sequence S for exon-intron boundary signals
- Outputs sliding window scores
- Identifies top-scoring candidate positions

**Output:**
- Count matrix
- Weight matrix (with pseudocounts)
- Relative frequencies matrix
- Log-likelihood matrix
- Sliding window analysis results

### ex2.py
Advanced implementation that analyzes real influenza genomes from NCBI.

**Features:**
- Downloads 10 influenza genomes from NCBI
- Scans each genome for motif signals
- Generates visualization of motif score landscapes
- Identifies top 5 candidate splice sites per genome
- Creates multi-panel figure with all results

**Output:**
- PNG file: `influenza_10_genomes_motif_signals.png`
- 10-panel plot showing motif scores across each genome

## Usage

### Basic Analysis (ex1.py)

```bash
python ex1.py
```

**Output Example:**
```
Motif length L=9, number of sequences N=9, pseudocount alpha=1.0

1) Count matrix
pos      1      2      3      4      5      6      7      8      9
  A      4      1      3      2      0      2      5      3      2
  C      1      3      1      2      0      0      0      1      1
  G      2      1      5      1      9      0      0      1      1
  T      2      4      0      4      0      7      4      4      5

2) Weight matrix (counts + alpha)
...

3) Relative frequencies matrix
...

4) Log-likelihood matrix (ln(P/0.25))
...

5) Sliding window scores on S
start= 0  window=CAGGTTGGA  score=7.234
start= 1  window=AGGTTGGAA  score=3.456
...

Top 5 windows (highest scores):
start= 0  window=CAGGTTGGA  score=7.234
...
```

### Genome Analysis (ex2.py)

```bash
python ex2.py
```

**Output:**
- Downloads 10 influenza genomes
- Processes each genome
- Saves visualization: `influenza_10_genomes_motif_signals.png`
- Shows motif score landscape across entire genome
- Highlights top 5 candidate positions

## Algorithm Details

### Step 1: Count Matrix

Count the occurrence of each nucleotide at each position across all motif sequences.

**Example:**
```
Position:  1  2  3  4  5  6  7  8  9
A:         4  1  3  2  0  2  5  3  2
C:         1  3  1  2  0  0  0  1  1
G:         2  1  5  1  9  0  0  1  1
T:         2  4  0  4  0  7  4  4  5
```

### Step 2: Weight Matrix (Pseudocounts)

Add pseudocount α (default: 1.0) to avoid zero probabilities:
```
Weight[b][i] = Count[b][i] + α
```

This prevents taking log of zero in later steps.

### Step 3: Relative Frequencies Matrix

Convert counts to probabilities:
```
Freq[b][i] = Weight[b][i] / (Sum of all bases at position i)
```

Each column sums to 1.0, representing probability distribution.

### Step 4: Log-Likelihood Matrix

Calculate log-odds ratio against background (null) probability:
```
LogLik[b][i] = ln(Freq[b][i] / null_prob)
```

Where `null_prob = 0.25` (assuming uniform background distribution).

**Interpretation:**
- **Positive values**: Nucleotide more common than background
- **Negative values**: Nucleotide less common than background
- **Zero**: Equal to background

### Step 5: Sequence Scanning

Score each possible 9-nucleotide window in sequence S:
```
Score(window) = Σ LogLik[window[i]][i] for i=0 to L-1
```

Higher scores indicate better match to the motif.

## Known Motif Sequences

The 9 exon-intron boundary motifs:
```
1. GAGGTAAAC
2. TCCGTAAGT
3. CAGGTTGGA
4. ACAGTCAGT
5. TAGGTCATT
6. TAGGTACTG
7. ATGGTAACT
8. CAGGTATAC
9. TGTGTGAGT
10. AAGGTAAGT
```

**Consensus pattern**: Strong preference for GT at positions 5-6 (canonical splice donor site)

## Test Sequence

```
S = "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA"
```

**Question**: Does S contain exon-intron border signals?

**Analysis approach**:
1. Scan S with 9-nucleotide sliding window
2. Score each window using log-likelihood matrix
3. Identify high-scoring windows
4. Compare scores to threshold or background distribution

## Interpretation

### High Scoring Windows

Windows with high positive scores likely contain:
- Splice donor sites (exon-intron boundary)
- Characteristic GT dinucleotide
- Flanking sequence context matching known motifs

### Low Scoring Windows

Negative or low scores indicate:
- Poor match to splice site consensus
- Unlikely to be functional splice sites
- May represent other sequence features

### Threshold Selection

Typical approaches:
- **Top-k selection**: Take k highest-scoring positions
- **Statistical significance**: Compare to background score distribution
- **Biological validation**: Confirm with experimental data

## Visualization (ex2.py)

The genome analysis generates a 10-panel figure showing:

**For each genome:**
- **X-axis**: Genomic position (base pairs)
- **Y-axis**: Log-likelihood score
- **Blue line**: Complete motif score landscape
- **Orange dots**: Top 5 candidate splice sites

**Features to observe:**
- Score peaks indicate potential splice sites
- Score distribution across genome
- Clustering of high-scoring regions
- Background score level

## Parameters

### Pseudocount (α)
- **Default**: 1.0
- **Purpose**: Avoid zero probabilities
- **Effect**: Smooths probability estimates
- **Higher values**: More conservative (pull toward background)
- **Lower values**: More aggressive (rely more on observed data)

### Null Probability
- **Default**: 0.25 (uniform distribution)
- **Purpose**: Background model for log-odds calculation
- **Alternative**: Use actual genome base composition

### Log Base
- **Default**: Natural log (e)
- **Alternatives**: log₂ (bits), log₁₀
- **Effect**: Scale of scores only (doesn't affect ranking)

### Minimum Distance (ex2.py)
- **Default**: 200 bp
- **Purpose**: Ensure peaks are well-separated
- **Effect**: Prevents finding redundant nearby positions

## Dependencies

### ex1.py
- Python 3.x
- Standard library: `math`, `collections`

### ex2.py
- Python 3.x
- `matplotlib`: Visualization
- Standard library: `math`, `time`, `urllib`, `collections`

**Installation:**
```bash
pip install matplotlib
```

## Biological Context

### Splice Site Motifs

**Donor site (exon-intron boundary)**:
- Consensus: `AG|GTRAGT` (| = boundary)
- Almost always GT at +1,+2 positions
- R = purine (A or G)

**Acceptor site (intron-exon boundary)**:
- Consensus: `(Y)nNYAG|G`
- Y = pyrimidine (C or T)
- AG immediately before boundary

### Exon Definition

Early recognition step involving:
- Communication between 5' and 3' splice sites
- SR protein binding
- Exon size constraints (typical: 50-300 bp)
- Splice site strength correlation

## Results Interpretation

### For Test Sequence S

After running ex1.py, examine:
1. **Highest score**: Does it exceed typical threshold (e.g., >5)?
2. **Window sequence**: Does it contain GT at expected positions?
3. **Score distribution**: How does top score compare to average?
4. **Multiple peaks**: Are there several high-scoring regions?

**Expected finding**: Window starting at position 0 (`CAGGTTGGA`) should score highly due to:
- Contains GT at positions 4-5
- Matches known motif #3 exactly
- Flanking nucleotides match consensus

### For Influenza Genomes (ex2.py)

Examine visualization for:
- **Peak frequency**: How many potential splice sites per genome?
- **Score range**: What's the maximum score observed?
- **Distribution**: Are peaks evenly distributed or clustered?
- **Inter-genome variation**: Do all genomes show similar patterns?

## Advanced Features

### Position-Specific Scoring Matrix (PSSM)

The log-likelihood matrix is a PSSM used in:
- Transcription factor binding site prediction
- Promoter recognition
- Regulatory element discovery
- Protein-DNA interaction modeling

### Sliding Window Analysis

General technique applicable to:
- CpG island detection
- Repeat finding
- GC content analysis
- Any position-specific feature

## Limitations

1. **Fixed motif length**: Assumes all splice sites have same length signature
2. **Independence assumption**: Positions scored independently (ignores dinucleotide dependencies)
3. **No intron context**: Only uses exon-side sequence
4. **Background model**: Simple uniform distribution (doesn't account for GC bias)
5. **No machine learning**: Rule-based rather than trained classifier

## Future Enhancements

Possible improvements:
- **Variable motif length**: Adapt to different splice site types
- **Position dependencies**: Use higher-order Markov models
- **Both boundaries**: Model donor and acceptor sites together
- **Machine learning**: Neural networks, SVMs for classification
- **Comparative genomics**: Use conservation across species
- **RNA structure**: Consider secondary structure effects
- **Experimental validation**: Integrate RNA-seq data

## Project Submission

According to specification, submit as **Project_L10.zip** containing:

### a) ReadMe.txt
Author: Mara (or team members in order of involvement)

### b) Screenshots
- `ex1_1.png`: Console output from ex1.py
- `ex1_2.png`: Additional results
- `influenza_10_genomes_motif_signals.png`: Genome analysis visualization

### c) L10.zip
Complete project archive:
- Source code: ex1.py, ex2.py
- This README
- Any additional documentation

## References

- Splice site recognition and exon definition
- Position Weight Matrices (PWMs) in bioinformatics
- PSSM construction and applications
- Information theory in sequence analysis
- Computational gene prediction methods

## Troubleshooting

### Issue: NCBI Download Fails (ex2.py)
- **Solution**: Check internet connection; NCBI servers may be temporarily unavailable
- **Alternative**: Use local FASTA files

### Issue: No High Scores Found
- **Solution**: Check motif sequences are correctly formatted; verify pseudocount value

### Issue: Visualization Doesn't Appear
- **Solution**: Ensure matplotlib is installed; check file permissions for saving PNG

## Educational Value

This lab demonstrates:
- ✅ Fundamental motif discovery algorithms
- ✅ Statistical sequence analysis
- ✅ Log-odds scoring and information theory
- ✅ Real-world bioinformatics applications
- ✅ Integration with biological databases (NCBI)
- ✅ Data visualization for genomic features
