CpG ISLAND ANALYZER - Lab 13 Project
=====================================

Author: [Your Name Here]

Description:
This project implements a CpG island classification system using Hidden Markov Model principles and log-likelihood scoring.

Files Included:
- ex1.py: Main Python script implementing the CpG island analyzer
- ReadMe.txt: This file
- Screenshot.jpg: Output screenshots (to be added)

How to Run:
1. Ensure Python 3.x is installed on your system
2. Open a terminal/command prompt
3. Navigate to the project directory
4. Run: python ex1.py

Features Implemented:
1. Transition frequency counting for CpG+ model (from S1 sequence)
2. Transition frequency counting for CpG- model (from S2 sequence)
3. Calculation of transition probabilities with Laplace smoothing
4. Log-likelihood matrix calculation using log2(P+/P-)
5. Sequence scoring and classification based on log-likelihood
6. Detailed step-by-step output with analysis

Input Sequences:
- S1 (CpG Island): ATCGATTCGATATCATACACGTAT
- S2 (Non-Island): CTCGACTAGTATGAAGTCCACGCTTG
- Test Sequence: CAGGTTGGAAACGTAA

Result:
The test sequence "CAGGTTGGAAACGTAA" scored -32.557, indicating it does NOT belong to a CpG island.

Technical Notes:
- Pseudocount smoothing (0.01) is used to handle zero probabilities
- Log-likelihood calculated as log2(P_plus/P_minus)
- Positive scores indicate CpG island, negative scores indicate non-CpG island

Date: January 22, 2026
