import math
from collections import defaultdict
import tkinter as tk
from tkinter import ttk

def count_transitions(sequence):
    """
    Count transition frequencies from a given sequence.
    Returns a dictionary with counts for each nucleotide transition.
    """
    transitions = defaultdict(lambda: defaultdict(int))
    
    # Count transitions
    for i in range(len(sequence) - 1):
        current = sequence[i]
        next_nucleotide = sequence[i + 1]
        transitions[current][next_nucleotide] += 1
    
    return transitions

def calculate_transition_probabilities(transitions, nucleotides=['A', 'C', 'G', 'T'], pseudocount=0.01):
    """
    Convert transition counts to probabilities with Laplace smoothing (pseudocount).
    This prevents zero probabilities which would cause -inf in log calculations.
    """
    probabilities = {}
    
    for current in nucleotides:
        probabilities[current] = {}
        # Add pseudocount to all transitions
        total = sum(transitions[current].values()) + pseudocount * len(nucleotides)
        
        if total > 0:
            for next_nuc in nucleotides:
                probabilities[current][next_nuc] = (transitions[current][next_nuc] + pseudocount) / total
        else:
            # If no transitions from this nucleotide, use uniform probability
            for next_nuc in nucleotides:
                probabilities[current][next_nuc] = 0.25
    
    return probabilities

def print_transition_matrix(probabilities, title):
    """
    Print transition probability matrix in a readable format.
    """
    nucleotides = ['A', 'C', 'G', 'T']
    print(f"\n{title}")
    print("-" * 50)
    print(f"{'From/To':<10}", end="")
    for nuc in nucleotides:
        print(f"{nuc:>10}", end="")
    print()
    
    for current in nucleotides:
        print(f"{current:<10}", end="")
        for next_nuc in nucleotides:
            prob = probabilities[current][next_nuc]
            print(f"{prob:>10.3f}", end="")
        print()

def calculate_log_likelihood_matrix(prob_plus, prob_minus, nucleotides=['A', 'C', 'G', 'T']):
    """
    Calculate log-likelihood matrix: log2(P+/P-)
    """
    log_likelihood = {}
    
    for current in nucleotides:
        log_likelihood[current] = {}
        for next_nuc in nucleotides:
            p_plus = prob_plus[current][next_nuc]
            p_minus = prob_minus[current][next_nuc]
            
            # Handle division by zero and log of zero
            if p_plus > 0 and p_minus > 0:
                # log2(p_plus/p_minus) = log(p_plus/p_minus) / log(2)
                log_likelihood[current][next_nuc] = math.log(p_plus / p_minus) / math.log(2)
            elif p_plus > 0 and p_minus == 0:
                log_likelihood[current][next_nuc] = float('inf')  # Very high score
            elif p_plus == 0 and p_minus > 0:
                log_likelihood[current][next_nuc] = float('-inf')  # Very low score
            else:
                log_likelihood[current][next_nuc] = 0  # Both zero
    
    return log_likelihood

def print_log_likelihood_matrix(log_likelihood, title="Log-Likelihood Matrix (β)"):
    """
    Print log-likelihood matrix in a readable format.
    """
    nucleotides = ['A', 'C', 'G', 'T']
    print(f"\n{title}")
    print("-" * 50)
    print(f"{'From/To':<10}", end="")
    for nuc in nucleotides:
        print(f"{nuc:>10}", end="")
    print()
    
    for current in nucleotides:
        print(f"{current:<10}", end="")
        for next_nuc in nucleotides:
            score = log_likelihood[current][next_nuc]
            if score == float('inf'):
                print(f"{'inf':>10}", end="")
            elif score == float('-inf'):
                print(f"{'-inf':>10}", end="")
            else:
                print(f"{score:>10.3f}", end="")
        print()

def display_log_likelihood_gui(log_likelihood, prob_plus, prob_minus):
    """
    Display log-likelihood matrix and transition matrices in a GUI window.
    """
    nucleotides = ['A', 'C', 'G', 'T']
    
    # Create main window
    root = tk.Tk()
    root.title("CpG Island Analysis - Log-Likelihood Matrix")
    root.geometry("1100x700")
    root.configure(bg='white')
    
    # Create main frame
    main_frame = tk.Frame(root, bg='white')
    main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
    
    # Title
    title_label = tk.Label(main_frame, text="CpG Island Analysis - Transition Matrices", 
                          font=('Arial', 16, 'bold'), bg='white')
    title_label.pack(pady=(0, 15))
    
    # Top frame for (+) and (-) matrices side by side
    top_frame = tk.Frame(main_frame, bg='white')
    top_frame.pack(pady=10)
    
    # Left: (+) Model
    plus_frame = tk.Frame(top_frame, bg='white')
    plus_frame.pack(side=tk.LEFT, padx=20)
    create_matrix_display_compact(plus_frame, prob_plus, "(+) Model - CpG Island", nucleotides, False)
    
    # Right: (-) Model
    minus_frame = tk.Frame(top_frame, bg='white')
    minus_frame.pack(side=tk.LEFT, padx=20)
    create_matrix_display_compact(minus_frame, prob_minus, "(-) Model - Non-Island", nucleotides, False)
    
    # Middle section: Formula
    formula_frame = tk.Frame(main_frame, bg='white')
    formula_frame.pack(pady=15)
    
    formula_label = tk.Label(formula_frame, text="log-likelihood = log₂(Tr⁺ᵢⱼ / Tr⁻ᵢⱼ)", 
                            font=('Arial', 13, 'italic'), bg='white', fg='#333333')
    formula_label.pack()
    
    # Bottom: Log-Likelihood Matrix
    bottom_frame = tk.Frame(main_frame, bg='white')
    bottom_frame.pack(pady=10)
    create_matrix_display_compact(bottom_frame, log_likelihood, "β (Log-Likelihood Matrix)", nucleotides, True)
    
    root.mainloop()

def create_matrix_display_compact(parent, matrix, title, nucleotides, is_log_likelihood=False):
    """
    Create a compact matrix display widget.
    """
    # Title
    title_label = tk.Label(parent, text=title, font=('Arial', 12, 'bold'), bg='white')
    title_label.pack(pady=5)
    
    # Create frame for matrix
    matrix_frame = tk.Frame(parent, bg='white')
    matrix_frame.pack()
    
    # Determine header text
    header_text = "β" if is_log_likelihood else "(+)" if "CpG Island" in title else "(-)"
    
    # Header row
    tk.Label(matrix_frame, text=header_text, font=('Arial', 11, 'bold'), 
             bg='#FFE6CC', width=6, height=2, relief=tk.SOLID, borderwidth=1).grid(row=0, column=0, padx=1, pady=1)
    
    for j, nuc in enumerate(nucleotides):
        tk.Label(matrix_frame, text=nuc, font=('Arial', 11, 'bold'), 
                bg='#FFE6CC', width=6, height=2, relief=tk.SOLID, borderwidth=1).grid(row=0, column=j+1, padx=1, pady=1)
    
    # Matrix cells
    for i, current in enumerate(nucleotides):
        # Row header
        tk.Label(matrix_frame, text=current, font=('Arial', 11, 'bold'), 
                bg='#FFE6CC', width=6, height=2, relief=tk.SOLID, borderwidth=1).grid(row=i+1, column=0, padx=1, pady=1)
        
        for j, next_nuc in enumerate(nucleotides):
            value = matrix[current][next_nuc]
            
            if is_log_likelihood:
                # Color coding for log-likelihood
                if value > 1:
                    bg_color = '#90EE90'  # Light green
                elif value > 0:
                    bg_color = '#E0FFE0'  # Very light green
                elif value < -1:
                    bg_color = '#FFB6C1'  # Light red/pink
                elif value < 0:
                    bg_color = '#FFE0E6'  # Very light red
                else:
                    bg_color = 'white'
                
                # Format value
                if abs(value) < 0.001 and value != 0:
                    text = "0"
                else:
                    text = f"{value:.3f}" if abs(value) < 10 else f"{value:.2f}"
            else:
                # Color coding for probabilities (highlight higher values)
                if value > 0.4:
                    bg_color = '#FFFFCC'  # Light yellow
                elif value > 0.25:
                    bg_color = '#FFFFE0'  # Very light yellow
                else:
                    bg_color = 'white'
                text = f"{value:.2f}"
            
            tk.Label(matrix_frame, text=text, font=('Arial', 10), 
                    bg=bg_color, width=6, height=2, relief=tk.SOLID, borderwidth=1).grid(row=i+1, column=j+1, padx=1, pady=1)

def score_sequence(sequence, log_likelihood):
    """
    Score a sequence using the log-likelihood matrix.
    Returns the total log-likelihood score.
    """
    total_score = 0
    scores = []
    
    print(f"\nScoring sequence: {sequence}")
    print("-" * 50)
    
    for i in range(len(sequence) - 1):
        current = sequence[i]
        next_nuc = sequence[i + 1]
        score = log_likelihood[current][next_nuc]
        scores.append(score)
        print(f"Position {i}: {current} -> {next_nuc}: {score:.3f}")
        total_score += score
    
    return total_score, scores

def main():
    # Define sequences
    S1 = "ATCGATTCGATATCATACACGTAT"  # CpG island (+)
    S2 = "CTCGACTAGTATGAAGTCCACGCTTG"  # Non-CpG island (-)
    S = "CAGGTTGGAAACGTAA"  # Test sequence
    
    print("=" * 70)
    print("CpG ISLAND ANALYSIS USING LOG-LIKELIHOOD SCORING")
    print("=" * 70)
    
    print(f"\nInput Sequences:")
    print(f"S1 (CpG Island +): {S1}")
    print(f"S2 (Non-Island -): {S2}")
    print(f"Test Sequence S:   {S}")
    
    # Step 1: Count transitions for CpG+ model (S1)
    print("\n" + "=" * 70)
    print("STEP 1: Count Transitions for CpG+ Model (S1)")
    print("=" * 70)
    transitions_plus = count_transitions(S1)
    
    print("\nTransition Counts for S1:")
    for current in ['A', 'C', 'G', 'T']:
        print(f"From {current}: ", end="")
        for next_nuc in ['A', 'C', 'G', 'T']:
            count = transitions_plus[current][next_nuc]
            print(f"{next_nuc}:{count} ", end="")
        print()
    
    prob_plus = calculate_transition_probabilities(transitions_plus)
    print_transition_matrix(prob_plus, "Transition Probabilities for CpG+ Model (M1)")
    
    # Step 2: Count transitions for CpG- model (S2)
    print("\n" + "=" * 70)
    print("STEP 2: Count Transitions for CpG- Model (S2)")
    print("=" * 70)
    transitions_minus = count_transitions(S2)
    
    print("\nTransition Counts for S2:")
    for current in ['A', 'C', 'G', 'T']:
        print(f"From {current}: ", end="")
        for next_nuc in ['A', 'C', 'G', 'T']:
            count = transitions_minus[current][next_nuc]
            print(f"{next_nuc}:{count} ", end="")
        print()
    
    prob_minus = calculate_transition_probabilities(transitions_minus)
    print_transition_matrix(prob_minus, "Transition Probabilities for CpG- Model (M2)")
    
    # Step 3: Calculate log-likelihood matrix
    print("\n" + "=" * 70)
    print("STEP 3: Calculate Log-Likelihood Matrix")
    print("=" * 70)
    log_likelihood = calculate_log_likelihood_matrix(prob_plus, prob_minus)
    print_log_likelihood_matrix(log_likelihood)
    
    # Display GUI window with matrices
    print("\n[Opening GUI window with matrix visualization...]")
    display_log_likelihood_gui(log_likelihood, prob_plus, prob_minus)
    
    # Step 4: Score the test sequence
    print("\n" + "=" * 70)
    print("STEP 4: Classify Test Sequence")
    print("=" * 70)
    total_score, scores = score_sequence(S, log_likelihood)
    
    print(f"\n{'=' * 70}")
    print(f"FINAL RESULTS")
    print(f"{'=' * 70}")
    print(f"Total Log-Likelihood Score: {total_score:.3f}")
    print(f"\nInterpretation:")
    if total_score > 0:
        print(f"✓ Score is POSITIVE ({total_score:.3f} > 0)")
        print(f"→ Sequence '{S}' likely belongs to a CpG ISLAND")
    elif total_score < 0:
        print(f"✗ Score is NEGATIVE ({total_score:.3f} < 0)")
        print(f"→ Sequence '{S}' likely does NOT belong to a CpG island")
    else:
        print(f"○ Score is ZERO")
        print(f"→ Sequence '{S}' is ambiguous")
    
    print(f"\n{'=' * 70}\n")

if __name__ == "__main__":
    main()
