import math
from collections import defaultdict
import re
import tkinter as tk
from tkinter import ttk, scrolledtext

# Sample poems for analysis
EMINESCU_POEM = """
Peste varfuri trece luna,
Codru-si bate frunza lin,
Dintre ramuri de arin
Melancolic cornul suna.
Pe campii in zarea bruna
Dor de ducă si venire,
Egg un cintec de jale
Indepartata-aducere.
Luna peste varfuri trece,
Tremurat de ginduri line,
Singuratice suspine
Ies din codrul care tace.
Doruri-n inimi se aprind,
Peste varfuri luna piere
Scumpă doină de durere
Peste codri se imprasie.
"""

STANESCU_POEM = """
Cuvintele sunt turnuri si castele
si cai de piatra ce galopează
prin negura timpului.
Cuvintele sunt copaci batrani
sub care ne-am odihni candva
intr-o seară de vara lunga.
Cuvintele zidesc catedrale
si dărîma cetăti,
cuvintele sunt pasari libere
ce zboara peste mări si tări.
Poezia e un dans al cuvintelor
ce se invîrt in ritmul vietii
si-al mortii deopotriva.
Cuvintele sunt semne pe hartă
pentru cei ce caută drumul
spre inimă si adevar.
"""

ACCUSED_TEXT = """
Peste varfuri trece luna un cal negru cu picioarele rupte
Codru-si bate frunza lin cuvintele sunt turnuri inalte
Dintre ramuri de arin galopează prin negura timpului
Melancolic cornul suna poezia e un dans al cuvintelor
Doruri-n inimi se aprind sub care ne-am odihni candva
Luna peste varfuri trece cuvintele zidesc catedrale
Intr-o seară de vara lunga tremurat de ginduri line
Cuvintele sunt semne pe hartă peste codri se imprasie
"""

def preprocess_text(text):
    """
    Clean and tokenize text into words.
    """
    # Convert to lowercase and remove punctuation
    text = text.lower()
    text = re.sub(r'[^\w\s]', ' ', text)
    # Split into words
    words = text.split()
    # Remove empty strings
    words = [w for w in words if w]
    return words

def count_word_transitions(words):
    """
    Count transition frequencies between consecutive words.
    """
    transitions = defaultdict(lambda: defaultdict(int))
    
    for i in range(len(words) - 1):
        current = words[i]
        next_word = words[i + 1]
        transitions[current][next_word] += 1
    
    return transitions

def calculate_transition_probabilities(transitions, all_words, pseudocount=0.001):
    """
    Convert transition counts to probabilities with smoothing.
    """
    probabilities = {}
    
    for current in all_words:
        probabilities[current] = {}
        total = sum(transitions[current].values()) + pseudocount * len(all_words)
        
        for next_word in all_words:
            probabilities[current][next_word] = (transitions[current][next_word] + pseudocount) / total
    
    return probabilities

def calculate_log_likelihood_matrix(prob_eminescu, prob_stanescu, all_words):
    """
    Calculate log-likelihood matrix: log2(P_stanescu/P_eminescu)
    Positive score = matches Stănescu more
    Negative score = matches Eminescu more (authentic)
    """
    log_likelihood = {}
    
    for current in all_words:
        log_likelihood[current] = {}
        for next_word in all_words:
            p_eminescu = prob_eminescu.get(current, {}).get(next_word, 0.0001)
            p_stanescu = prob_stanescu.get(current, {}).get(next_word, 0.0001)
            
            if p_eminescu > 0 and p_stanescu > 0:
                # Swap: Stănescu / Eminescu so negative = Eminescu
                log_likelihood[current][next_word] = math.log(p_stanescu / p_eminescu) / math.log(2)
            else:
                log_likelihood[current][next_word] = 0
    
    return log_likelihood

def sliding_window_analysis(words, log_likelihood, window_size=3):
    """
    Analyze text using sliding window and log-likelihood scoring.
    Returns list of (window_text, score, position, classification) tuples.
    """
    results = []
    threshold = 0.3  # Threshold for classification
    
    for i in range(len(words) - window_size + 1):
        window = words[i:i + window_size]
        score = 0
        valid_transitions = 0
        
        # Calculate score for this window
        for j in range(len(window) - 1):
            current = window[j]
            next_word = window[j + 1]
            
            if current in log_likelihood and next_word in log_likelihood[current]:
                score += log_likelihood[current][next_word]
                valid_transitions += 1
        
        avg_score = score / valid_transitions if valid_transitions > 0 else 0
        
        # Classify based on score
        # Negative score = Eminescu higher probability (authentic)
        # Positive score = Stănescu higher probability (plagiarized)
        if avg_score < -threshold:
            classification = "EMINESCU"
            color = "#E6F3FF"  # Light blue
        elif avg_score > threshold:
            classification = "STĂNESCU"
            color = "#FFE6E6"  # Light red
        else:
            classification = "NEITHER"
            color = "#F5F5F5"  # Light gray
        
        window_text = ' '.join(window)
        results.append((window_text, avg_score, i, classification, color))
    
    return results

def display_results_gui(results, overall_score, eminescu_words, stanescu_words, accused_words):
    """
    Display plagiarism analysis results in a GUI.
    """
    root = tk.Tk()
    root.title("Poetry Plagiarism Detection - Courtroom Evidence")
    root.geometry("1000x700")
    root.configure(bg='white')
    
    # Main frame
    main_frame = tk.Frame(root, bg='white', padx=20, pady=20)
    main_frame.pack(fill=tk.BOTH, expand=True)
    
    # Title
    title_label = tk.Label(main_frame, 
                          text="🏛️ COURTROOM PLAGIARISM ANALYSIS 🏛️",
                          font=('Arial', 18, 'bold'), bg='white', fg='#1a1a1a')
    title_label.pack(pady=(0, 10))
    
    # Case info
    case_frame = tk.Frame(main_frame, bg='#f0f0f0', relief=tk.RIDGE, borderwidth=2)
    case_frame.pack(fill=tk.X, pady=10)
    
    tk.Label(case_frame, text="Case: Mihai Eminescu vs. Plagiarism Allegations", 
            font=('Arial', 12, 'bold'), bg='#f0f0f0').pack(pady=5)
    tk.Label(case_frame, text="Analysis Method: Word Transition Log-Likelihood Scoring", 
            font=('Arial', 10, 'italic'), bg='#f0f0f0').pack(pady=2)
    
    # Overall verdict
    verdict_frame = tk.Frame(main_frame, bg='white')
    verdict_frame.pack(pady=10, fill=tk.X)
    
    tk.Label(verdict_frame, text="OVERALL SCORE:", 
            font=('Arial', 14, 'bold'), bg='white').pack(side=tk.LEFT, padx=10)
    
    # Negative score = Eminescu, Positive score = Stănescu
    score_color = '#2ecc71' if overall_score < 0 else '#e74c3c' if overall_score > 0 else '#95a5a6'
    verdict_text = "AUTHENTIC EMINESCU" if overall_score < 0 else "PLAGIARIZED FROM STĂNESCU" if overall_score > 0 else "NEUTRAL"
    
    tk.Label(verdict_frame, text=f"{overall_score:.3f}", 
            font=('Arial', 14, 'bold'), bg=score_color, fg='white',
            padx=15, pady=5, relief=tk.RAISED).pack(side=tk.LEFT, padx=5)
    
    tk.Label(verdict_frame, text=f"→ {verdict_text}", 
            font=('Arial', 14, 'bold'), bg='white', fg=score_color).pack(side=tk.LEFT, padx=10)
    
    # Statistics
    stats_frame = tk.Frame(main_frame, bg='white')
    stats_frame.pack(pady=10, fill=tk.X)
    
    tk.Label(stats_frame, text=f"📊 Eminescu vocabulary: {len(eminescu_words)} unique words", 
            font=('Arial', 10), bg='white').pack(anchor=tk.W)
    tk.Label(stats_frame, text=f"📊 Stanescu vocabulary: {len(stanescu_words)} unique words", 
            font=('Arial', 10), bg='white').pack(anchor=tk.W)
    tk.Label(stats_frame, text=f"📊 Accused text: {len(accused_words)} words analyzed", 
            font=('Arial', 10), bg='white').pack(anchor=tk.W)
    
    # Notebook for tabs
    notebook = ttk.Notebook(main_frame)
    notebook.pack(fill=tk.BOTH, expand=True, pady=10)
    
    # Tab 1: Sliding Window Results
    tab1 = tk.Frame(notebook, bg='white')
    notebook.add(tab1, text='Sliding Window Analysis')
    
    # Create treeview for results
    columns = ('Position', 'Window Text', 'Score', 'Interpretation')
    tree = ttk.Treeview(tab1, columns=columns, show='headings', height=15)
    
    tree.heading('Position', text='Position')
    tree.heading('Window Text', text='Text Window')
    tree.heading('Score', text='Score')
    tree.heading('Interpretation', text='Style')
    
    tree.column('Position', width=80, anchor=tk.CENTER)
    tree.column('Window Text', width=400, anchor=tk.W)
    tree.column('Score', width=100, anchor=tk.CENTER)
    tree.column('Interpretation', width=150, anchor=tk.CENTER)
    
    # Add scrollbar
    scrollbar = ttk.Scrollbar(tab1, orient=tk.VERTICAL, command=tree.yview)
    tree.configure(yscroll=scrollbar.set)
    
    # Insert data with color coding
    eminescu_count = 0
    stanescu_count = 0
    neither_count = 0
    
    for window_text, score, position, classification, color in results:
        # Track counts
        if classification == "EMINESCU":
            eminescu_count += 1
            tag = 'eminescu'
        elif classification == "STĂNESCU":
            stanescu_count += 1
            tag = 'stanescu'
        else:
            neither_count += 1
            tag = 'neither'
        
        tree.insert('', tk.END, values=(position, window_text, f"{score:.3f}", classification), tags=(tag,))
    
    # Configure row colors
    tree.tag_configure('eminescu', background='#E6F3FF')
    tree.tag_configure('stanescu', background='#FFE6E6')
    tree.tag_configure('neither', background='#F5F5F5')
    
    tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    # Tab 2: Visual Text Highlighting
    tab2 = tk.Frame(notebook, bg='white')
    notebook.add(tab2, text='Visual Text Analysis')
    
    text_widget = tk.Text(tab2, wrap=tk.WORD, font=('Courier', 11), height=20, padx=10, pady=10)
    text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    # Configure tags for highlighting
    text_widget.tag_configure('eminescu', background='#E6F3FF', foreground='#0066CC')
    text_widget.tag_configure('stanescu', background='#FFE6E6', foreground='#CC0000')
    text_widget.tag_configure('neither', background='#F5F5F5', foreground='#666666')
    
    # Build highlighted text
    words = ACCUSED_TEXT.lower().split()
    word_classifications = {}
    
    # Determine classification for each word based on windows it appears in
    for window_text, score, position, classification, color in results:
        for offset in range(3):  # window_size = 3
            word_pos = position + offset
            if word_pos < len(words):
                if word_pos not in word_classifications:
                    word_classifications[word_pos] = []
                word_classifications[word_pos].append(classification)
    
    # Insert text with highlights
    for i, word in enumerate(words):
        if i in word_classifications:
            # Get dominant classification by majority vote
            classifications = word_classifications[i]
            eminescu_votes = classifications.count('EMINESCU')
            stanescu_votes = classifications.count('STĂNESCU')
            neither_votes = classifications.count('NEITHER')
            
            if eminescu_votes > stanescu_votes and eminescu_votes > neither_votes:
                tag = 'eminescu'
            elif stanescu_votes > eminescu_votes and stanescu_votes > neither_votes:
                tag = 'stanescu'
            else:
                tag = 'neither'
        else:
            tag = 'neither'
        
        text_widget.insert(tk.END, word + ' ', tag)
    
    text_widget.config(state=tk.DISABLED)
    
    # Add legend
    legend_frame = tk.Frame(tab2, bg='white')
    legend_frame.pack(pady=5)
    
    tk.Label(legend_frame, text="Legend:", font=('Arial', 10, 'bold'), bg='white').pack(side=tk.LEFT, padx=5)
    tk.Label(legend_frame, text="  Eminescu  ", bg='#E6F3FF', fg='#0066CC', 
            relief=tk.RAISED, borderwidth=1, padx=5).pack(side=tk.LEFT, padx=3)
    tk.Label(legend_frame, text="  Stănescu  ", bg='#FFE6E6', fg='#CC0000', 
            relief=tk.RAISED, borderwidth=1, padx=5).pack(side=tk.LEFT, padx=3)
    tk.Label(legend_frame, text="  Neither  ", bg='#F5F5F5', fg='#666666', 
            relief=tk.RAISED, borderwidth=1, padx=5).pack(side=tk.LEFT, padx=3)
    
    # Tab 3: Detailed Report
    tab3 = tk.Frame(notebook, bg='white')
    notebook.add(tab3, text='Statistical Report')
    
    report_text = scrolledtext.ScrolledText(tab3, wrap=tk.WORD, font=('Courier', 10))
    report_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    # Generate report
    report = "=" * 80 + "\n"
    report += "PLAGIARISM ANALYSIS REPORT\n"
    report += "=" * 80 + "\n\n"
    
    report += "EVIDENCE ANALYSIS:\n"
    report += "-" * 80 + "\n"
    
    total = len(results)
    report += f"Total windows analyzed: {total}\n"
    report += f"Windows matching Eminescu style: {eminescu_count} ({eminescu_count/total*100:.1f}%)\n"
    report += f"Windows matching Stănescu style: {stanescu_count} ({stanescu_count/total*100:.1f}%)\n"
    report += f"Neutral/ambiguous windows: {neither_count} ({neither_count/total*100:.1f}%)\n\n"
    
    report += "LAWYER'S ARGUMENT:\n"
    report += "-" * 80 + "\n"
    
    if eminescu_count > stanescu_count:
        report += "✓ DEFENSE: The accused text shows STRONG similarity to Eminescu's writing style.\n"
        report += f"  {eminescu_count} out of {total} windows match Eminescu's own patterns.\n"
        report += "  This proves Mihai Eminescu wrote this in his own authentic style,\n"
        report += "  not plagiarized from Stănescu.\n\n"
        report += "  VERDICT: INNOCENT - Text is authentic Eminescu, not plagiarized.\n\n"
    elif stanescu_count > eminescu_count:
        report += "⚠ PROSECUTION: The accused text shows similarity to Stănescu's writing style.\n"
        report += f"  {stanescu_count} out of {total} windows match Stănescu's patterns.\n"
        report += "  This indicates influence from or plagiarism of Stănescu's work.\n\n"
        report += "  VERDICT: GUILTY - Plagiarism detected from Stănescu.\n\n"
    else:
        report += "○ INCONCLUSIVE: The text shows mixed characteristics of both poets.\n"
        report += "  Further investigation required.\n\n"
    
    report += "\nDETAILED WINDOW ANALYSIS:\n"
    report += "-" * 80 + "\n"
    report += f"{'Pos':<5} {'Window Text':<40} {'Score':<10} {'Classification':<15}\n"
    report += "-" * 80 + "\n"
    
    for window_text, score, position, classification, color in results:
        report += f"{position:<5} {window_text[:38]:<40} {score:>8.3f}  {classification:<15}\n"
    
    report += "\n" + "=" * 80 + "\n"
    report += "KEY:\n"
    report += "  Negative Score → Eminescu style\n"
    report += "  Positive Score → Stănescu style\n"
    report += "  Near Zero → Neither author (uncertain)\n"
    report += "=" * 80 + "\n"
    
    report_text.insert('1.0', report)
    report_text.config(state=tk.DISABLED)
    
    # Conclusion
    conclusion_frame = tk.Frame(main_frame, bg='#f9f9f9', relief=tk.RIDGE, borderwidth=2)
    conclusion_frame.pack(fill=tk.X, pady=10)
    
    if overall_score > 0:
        conclusion_text = "⚖️ VERDICT: Evidence suggests the text matches EMINESCU's style.\nDefense argues this proves original composition, not plagiarism."
        conclusion_color = '#27ae60'
    elif overall_score < 0:
        conclusion_text = "⚖️ VERDICT: Evidence suggests the text matches STANESCU's style.\nProsecution may argue this indicates plagiarism or influence."
        conclusion_color = '#c0392b'
    else:
        conclusion_text = "⚖️ VERDICT: Evidence is INCONCLUSIVE. Further analysis recommended."
        conclusion_color = '#7f8c8d'
    
    tk.Label(conclusion_frame, text=conclusion_text, 
            font=('Arial', 11, 'bold'), bg='#f9f9f9', fg=conclusion_color,
            justify=tk.LEFT).pack(pady=10, padx=10)
    
    root.mainloop()

def main():
    print("=" * 80)
    print("PLAGIARISM DETECTION SYSTEM - COURTROOM ANALYSIS")
    print("=" * 80)
    print("\n📋 Case: Mihai accused of plagiarism")
    print("🎯 Method: Word Transition Matrix Analysis with Log-Likelihood Scoring\n")
    
    # Step 1: Preprocess texts
    print("STEP 1: Preprocessing Poetry Samples")
    print("-" * 80)
    
    eminescu_words = preprocess_text(EMINESCU_POEM)
    stanescu_words = preprocess_text(STANESCU_POEM)
    accused_words = preprocess_text(ACCUSED_TEXT)
    
    print(f"Eminescu poem: {len(eminescu_words)} words")
    print(f"Stanescu poem: {len(stanescu_words)} words")
    print(f"Accused text: {len(accused_words)} words")
    
    # Get all unique words
    all_words = set(eminescu_words + stanescu_words + accused_words)
    print(f"Total unique vocabulary: {len(all_words)} words\n")
    
    # Step 2: Build transition matrices
    print("STEP 2: Building Transition Matrices")
    print("-" * 80)
    
    eminescu_transitions = count_word_transitions(eminescu_words)
    stanescu_transitions = count_word_transitions(stanescu_words)
    
    print(f"Eminescu transitions: {sum(len(v) for v in eminescu_transitions.values())} pairs")
    print(f"Stanescu transitions: {sum(len(v) for v in stanescu_transitions.values())} pairs\n")
    
    # Step 3: Calculate probabilities
    print("STEP 3: Calculating Transition Probabilities")
    print("-" * 80)
    
    prob_eminescu = calculate_transition_probabilities(eminescu_transitions, all_words)
    prob_stanescu = calculate_transition_probabilities(stanescu_transitions, all_words)
    
    print("Transition probability matrices created with smoothing\n")
    
    # Step 4: Calculate log-likelihood matrix
    print("STEP 4: Creating Log-Likelihood Matrix")
    print("-" * 80)
    
    log_likelihood = calculate_log_likelihood_matrix(prob_eminescu, prob_stanescu, all_words)
    print("Log-likelihood matrix: log₂(P_Eminescu / P_Stanescu)\n")
    
    # Step 5: Analyze accused text with sliding window
    print("STEP 5: Sliding Window Analysis of Accused Text")
    print("-" * 80)
    
    window_size = 3
    results = sliding_window_analysis(accused_words, log_likelihood, window_size)
    
    print(f"Window size: {window_size} words")
    print(f"Number of windows analyzed: {len(results)}\n")
    
    # Calculate overall score
    overall_score = sum(score for _, score, _, _, _ in results) / len(results) if results else 0
    
    print("Window Analysis Results:")
    print("-" * 80)
    for i, (window_text, score, position, classification, color) in enumerate(results[:10]):  # Show first 10
        print(f"{i+1:2d}. [{position:2d}] '{window_text[:40]:40s}' → {score:7.3f} ({classification})")
    
    if len(results) > 10:
        print(f"... and {len(results) - 10} more windows\n")
    
    # Final verdict
    print("\n" + "=" * 80)
    print("FINAL VERDICT")
    print("=" * 80)
    print(f"Overall Log-Likelihood Score: {overall_score:.4f}\n")
    
    # Count classifications
    eminescu_count = sum(1 for _, _, _, classification, _ in results if classification == "EMINESCU")
    stanescu_count = sum(1 for _, _, _, classification, _ in results if classification == "STĂNESCU")
    neither_count = sum(1 for _, _, _, classification, _ in results if classification == "NEITHER")
    
    print(f"Classification Breakdown:")
    print(f"  🔵 Eminescu style: {eminescu_count} windows ({eminescu_count/len(results)*100:.1f}%)")
    print(f"  🔴 Stănescu style: {stanescu_count} windows ({stanescu_count/len(results)*100:.1f}%)")
    print(f"  ⚪ Neither/Uncertain: {neither_count} windows ({neither_count/len(results)*100:.1f}%)\n")
    
    if eminescu_count > stanescu_count:
        print("✓ DEFENSE ARGUMENT:")
        print("  The accused text exhibits word transition patterns consistent with")
        print("  Mihai EMINESCU's own authentic writing style in the majority of segments.")
        print("  This proves Eminescu wrote this himself in his characteristic style,")
        print("  NOT plagiarized from Stănescu. The evidence supports INNOCENCE.\n")
    elif stanescu_count > eminescu_count:
        print("⚠ PROSECUTION ARGUMENT:")
        print("  The accused text exhibits word transition patterns consistent with")
        print("  STĂNESCU's writing style in the majority of analyzed segments.")
        print("  This indicates plagiarism or heavy influence from Stănescu's work.\n")
    else:
        print("○ INCONCLUSIVE:")
        print("  The text shows mixed characteristics of both poets' styles.")
        print("  Further analysis recommended.\n")
    
    print("=" * 80)
    print("\n[Opening GUI with detailed analysis...]\n")
    
    # Display GUI
    display_results_gui(results, overall_score, eminescu_words, stanescu_words, accused_words)

if __name__ == "__main__":
    main()
