# Lab 10: DNA Sequence Alignment - Needleman-Wunsch Algorithm

**Author:** Iubitu Mara, 1241EA

## Overview

This lab implements the Needleman-Wunsch global alignment algorithm with a graphical user interface (GUI). The application allows users to align two DNA sequences, visualize the scoring matrix and traceback path, and analyze alignment quality with detailed statistics.

## Background

### Needleman-Wunsch Algorithm

The Needleman-Wunsch algorithm is a dynamic programming approach for global sequence alignment. It finds the optimal alignment between two sequences by maximizing a scoring function that accounts for:
- **Matches**: Identical nucleotides at corresponding positions
- **Mismatches**: Different nucleotides at corresponding positions
- **Gaps**: Insertions or deletions represented by "-"

### Applications

- Comparing homologous genes across species
- Identifying conserved regions in DNA sequences
- Studying evolutionary relationships
- Detecting mutations and variations
- Sequence annotation and validation

## Files

### dna_alignment.py
Main application implementing Needleman-Wunsch algorithm with interactive GUI.

**Features:**
- Visual matrix representation with color gradient (blue to red)
- Traceback path visualization highlighting optimal alignment route
- Real-time parameter adjustment
- Detailed alignment statistics
- User-friendly interface with default sequences

## Usage

```bash
python dna_alignment.py
```

### GUI Interface

The application window is divided into two main sections:

#### Left Panel - Input Controls

1. **Sequences Section**
   - `Sq 1`: First DNA sequence to align
   - `Sq 2`: Second DNA sequence to align
   - Default sequences provided for testing

2. **Parameters Section**
   - `Gap`: Gap penalty (default: 0)
   - `Match`: Score for matching nucleotides (default: 1)
   - `MMach`: Penalty for mismatches (default: -1)

3. **Options Section**
   - `Plot TraceBack`: Toggle traceback path visualization
   - `Plot grid`: Toggle grid lines on visualizations

4. **Align Button**: Execute alignment with current settings

#### Right Panel - Results & Visualization

1. **Graphic Representation of the Alignment Matrix**
   - Color-coded scoring matrix
   - Blue = lower scores, Red = higher scores
   - Shows all possible alignment paths

2. **Traceback Path Deviation**
   - Highlights the optimal alignment path
   - Red cells = path taken
   - Yellow cells = alternative paths

3. **Show Alignment**
   - Aligned sequences with match indicators (|)
   - Alignment statistics (matches, length, similarity)
   - Complete scoring matrix table
   - Traceback starting position

## Algorithm Details

### Step 1: Initialize Scoring Matrix

Create a matrix `M[i][j]` where:
- Rows represent nucleotides from sequence 1
- Columns represent nucleotides from sequence 2
- First row: `M[0][j] = gap × j`
- First column: `M[i][0] = gap × i`

### Step 2: Fill Scoring Matrix

For each cell `M[i][j]`:
```
diagonal_score = M[i-1][j-1] + (match if seq1[i]==seq2[j] else mismatch)
up_score = M[i-1][j] + gap
left_score = M[i][j-1] + gap

M[i][j] = max(diagonal_score, up_score, left_score)
```

### Step 3: Traceback

Starting from `M[m][n]` (bottom-right corner):
- **Diagonal move**: Match or mismatch → align both nucleotides
- **Up move**: Gap in sequence 2 → add gap "-" to seq2
- **Left move**: Gap in sequence 1 → add gap "-" to seq1

Continue until reaching `M[0][0]` (top-left corner).

### Step 4: Calculate Statistics

- **Matches**: Count identical nucleotides (excluding gaps)
- **Length**: Total alignment length (including gaps)
- **Similarity**: `(matches / length) × 100%`

## Default Example

### Input Sequences
```
Sequence 1: ACCGTGAAGCCAATAC
Sequence 2: AGCGTGCAGCCAATAC
```

### Parameters
- Gap penalty: 0
- Match score: 1
- Mismatch penalty: -1

### Expected Output
```
A-ACCGTGAAGCCAATAC-AAGCCAATAC
   |  |||| |||||||||
AG-AGCGTGCAGCCAATAC-AGCCAATAC

Matches = 13
Length = 18
Similarity = 72%
```

## Scoring Parameters

### Gap Penalty
- **Negative values** (e.g., -2): Discourage gaps → fewer insertions/deletions
- **Zero**: Neutral → gaps treated equally to other moves
- **Positive values**: Rarely used, would encourage gaps

### Match Score
- **Positive values** (e.g., 1, 2): Reward identical nucleotides
- Higher values → prioritize exact matches

### Mismatch Penalty
- **Negative values** (e.g., -1, -2): Penalize different nucleotides
- More negative → stronger penalty for mismatches

## Visualization Guide

### Color-Coded Matrix

The scoring matrix uses a blue-to-red gradient:
- **Blue**: Low scores (poor alignment at that position)
- **Purple**: Medium scores
- **Red**: High scores (good alignment at that position)

This visualization helps identify:
- Regions of high similarity (red diagonals)
- Potential alignment paths
- Compositional differences

### Traceback Path

The traceback visualization shows:
- **Red cells**: Optimal alignment path chosen by the algorithm
- **Yellow cells**: All possible positions in the matrix
- **Grid lines**: Cell boundaries (optional)

The path always moves from bottom-right to top-left through:
- Diagonal steps (match/mismatch)
- Vertical steps (gap in sequence 2)
- Horizontal steps (gap in sequence 1)

## Use Cases

### 1. Gene Comparison
```
Sq 1: ATGCGATCGATCG
Sq 2: ATGCGATCGCTCG
```
Identify single nucleotide polymorphisms (SNPs).

### 2. Mutation Detection
```
Sq 1: AAAATTTCCCGGG
Sq 2: AAAATTTTCCGGG
```
Detect insertions, deletions, or substitutions.

### 3. Homology Analysis
```
Sq 1: ACGTACGTACGT
Sq 2: ACGTACGTACGT
```
Verify perfect sequence conservation.

## Advanced Features

### Custom Scoring Schemes

Adjust parameters for different alignment scenarios:

**Conservative (avoid gaps):**
- Gap: -5
- Match: 2
- Mismatch: -1

**Liberal (allow gaps):**
- Gap: 0
- Match: 1
- Mismatch: -2

**Strict matching:**
- Gap: -2
- Match: 5
- Mismatch: -3

## Dependencies

- Python 3.x
- `tkinter`: GUI framework (included with Python)
- `numpy`: Matrix operations

**Installation:**
```bash
pip install numpy
```

Note: `tkinter` is typically included with standard Python installations. If not available:
- **Ubuntu/Debian**: `sudo apt-get install python3-tk`
- **Fedora**: `sudo dnf install python3-tkinter`
- **macOS**: Included with Python from python.org

## Technical Details

### Matrix Dimensions

For sequences of length `m` and `n`:
- Matrix size: `(m+1) × (n+1)`
- First row/column: initialization for gaps
- Cell `[i][j]`: alignment up to position `i` in seq1 and `j` in seq2

### Complexity

- **Time Complexity**: O(m × n) - must fill entire matrix
- **Space Complexity**: O(m × n) - store scoring and traceback matrices

### Traceback Matrix

Stores direction taken at each cell:
- `0`: Diagonal (match/mismatch)
- `1`: Up (gap in sequence 2)
- `2`: Left (gap in sequence 1)

## Limitations

- **Global alignment only**: Always aligns entire sequences end-to-end
- **Single optimal path**: Shows one optimal path (may be multiple)
- **Linear gap penalty**: All gaps penalized equally regardless of length
- **No affine gap penalties**: Cannot model gap opening vs. extension differently

## Future Enhancements

Possible improvements:
- Smith-Waterman local alignment option
- Multiple sequence alignment support
- Affine gap penalties (different costs for opening vs. extending gaps)
- Export alignment to FASTA format
- Batch processing of multiple sequence pairs
- Support for protein sequences
- BLOSUM/PAM scoring matrices for proteins
- Alignment quality scores (e.g., bit scores)

## Biological Interpretation

### High Similarity (>80%)
- Likely orthologous genes (same gene in different species)
- Recent common ancestor
- Strong functional constraint

### Medium Similarity (50-80%)
- Possible homologs with divergence
- Conserved functional domains
- Evolutionary relationship

### Low Similarity (<50%)
- Distant homologs or unrelated sequences
- Significant evolutionary distance
- May require local alignment instead

## Troubleshooting

### Issue: Blank Visualizations
- **Solution**: Resize window or click "Align" button again

### Issue: Incorrect Alignment
- **Solution**: Check parameter signs (gap should be ≤ 0, match > 0, mismatch < 0)

### Issue: GUI Not Appearing
- **Solution**: Ensure tkinter is installed; try `python3 -m tkinter` to test

## References

- Needleman, S.B. and Wunsch, C.D. (1970) "A general method applicable to the search for similarities in the amino acid sequence of two proteins." Journal of Molecular Biology 48(3):443-453.
- Dynamic Programming in Sequence Alignment
- Global vs. Local Alignment Algorithms
