import tkinter as tk
from tkinter import ttk
import numpy as np

class DNAAlignmentApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DNA Sequence Alignment - Needleman-Wunsch Algorithm")
        self.root.geometry("1200x800")
        
        # Default sequences
        self.seq1_default = "ACCGTGAAGCCAATAC"
        self.seq2_default = "AGCGTGCAGCCAATAC"
        
        # Default parameters
        self.gap_penalty = 0
        self.match_score = 1
        self.mismatch_penalty = -1
        
        self.create_widgets()
        
    def create_widgets(self):
        # Left panel for input
        left_frame = tk.Frame(self.root, relief=tk.RAISED, borderwidth=2)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=10, pady=10)
        
        # Sequences section
        seq_frame = tk.LabelFrame(left_frame, text="Sequences", padx=10, pady=10)
        seq_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        tk.Label(seq_frame, text="Sq 1 =").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.seq1_entry = tk.Entry(seq_frame, width=25)
        self.seq1_entry.grid(row=0, column=1, pady=5)
        self.seq1_entry.insert(0, self.seq1_default)
        
        tk.Label(seq_frame, text="Sq 2 =").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.seq2_entry = tk.Entry(seq_frame, width=25)
        self.seq2_entry.grid(row=1, column=1, pady=5)
        self.seq2_entry.insert(0, self.seq2_default)
        
        # Parameters section
        param_frame = tk.LabelFrame(left_frame, text="Parameters", padx=10, pady=10)
        param_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        tk.Label(param_frame, text="Gap =").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.gap_entry = tk.Entry(param_frame, width=10)
        self.gap_entry.grid(row=0, column=1, pady=5)
        self.gap_entry.insert(0, "0")
        
        tk.Label(param_frame, text="Mach =").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.match_entry = tk.Entry(param_frame, width=10)
        self.match_entry.grid(row=1, column=1, pady=5)
        self.match_entry.insert(0, "1")
        
        tk.Label(param_frame, text="MMach =").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.mismatch_entry = tk.Entry(param_frame, width=10)
        self.mismatch_entry.grid(row=2, column=1, pady=5)
        self.mismatch_entry.insert(0, "-1")
        
        # Options section
        options_frame = tk.LabelFrame(left_frame, text="Options", padx=10, pady=10)
        options_frame.pack(fill=tk.BOTH, padx=5, pady=5)
        
        self.plot_traceback_var = tk.BooleanVar(value=True)
        self.plot_grid_var = tk.BooleanVar(value=True)
        
        tk.Checkbutton(options_frame, text="Plot TraceBack", variable=self.plot_traceback_var).pack(anchor=tk.W)
        tk.Checkbutton(options_frame, text="Plot grid", variable=self.plot_grid_var).pack(anchor=tk.W)
        
        # Align button
        align_btn = tk.Button(left_frame, text="Align", command=self.align_sequences, 
                            bg="#4CAF50", fg="white", font=("Arial", 12, "bold"))
        align_btn.pack(fill=tk.X, padx=5, pady=20)
        
        # Right panel for visualization
        right_frame = tk.Frame(self.root)
        right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Container for both canvases (side by side)
        canvases_container = tk.Frame(right_frame)
        canvases_container.pack(fill=tk.BOTH, pady=5)
        
        # Create canvas for matrix visualization
        canvas_frame = tk.LabelFrame(canvases_container, text="Graphic representation of the alignment matrix", padx=5, pady=5)
        canvas_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2)
        
        self.matrix_canvas = tk.Canvas(canvas_frame, bg="white", width=300, height=250)
        self.matrix_canvas.pack(fill=tk.BOTH, expand=True)
        
        # Create canvas for traceback path
        traceback_frame = tk.LabelFrame(canvases_container, text="Traceback path deviation from optimal alignment", padx=5, pady=5)
        traceback_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2)
        
        self.traceback_canvas = tk.Canvas(traceback_frame, bg="white", width=300, height=250)
        self.traceback_canvas.pack(fill=tk.BOTH, expand=True)
        
        # Result text area
        result_frame = tk.LabelFrame(right_frame, text="Show Alignment:", padx=5, pady=5)
        result_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.result_text = tk.Text(result_frame, height=10, width=80, font=("Courier", 10))
        self.result_text.pack(fill=tk.BOTH, expand=True)
        
    def needleman_wunsch(self, seq1, seq2, gap, match, mismatch):
        """Implement Needleman-Wunsch algorithm"""
        m, n = len(seq1), len(seq2)
        
        # Initialize scoring matrix
        score_matrix = np.zeros((m + 1, n + 1), dtype=int)
        traceback_matrix = np.zeros((m + 1, n + 1), dtype=int)
        
        # Initialize first row and column
        for i in range(1, m + 1):
            score_matrix[i][0] = gap * i
            traceback_matrix[i][0] = 1  # up
            
        for j in range(1, n + 1):
            score_matrix[0][j] = gap * j
            traceback_matrix[0][j] = 2  # left
            
        # Fill the matrices
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if seq1[i-1] == seq2[j-1]:
                    diag_score = score_matrix[i-1][j-1] + match
                else:
                    diag_score = score_matrix[i-1][j-1] + mismatch
                    
                up_score = score_matrix[i-1][j] + gap
                left_score = score_matrix[i][j-1] + gap
                
                max_score = max(diag_score, up_score, left_score)
                score_matrix[i][j] = max_score
                
                if max_score == diag_score:
                    traceback_matrix[i][j] = 0  # diagonal
                elif max_score == up_score:
                    traceback_matrix[i][j] = 1  # up
                else:
                    traceback_matrix[i][j] = 2  # left
                    
        return score_matrix, traceback_matrix
    
    def traceback(self, seq1, seq2, traceback_matrix):
        """Perform traceback to get alignment"""
        aligned_seq1 = ""
        aligned_seq2 = ""
        match_line = ""
        
        i, j = len(seq1), len(seq2)
        path = [(i, j)]
        
        while i > 0 or j > 0:
            if i > 0 and j > 0 and traceback_matrix[i][j] == 0:  # diagonal
                aligned_seq1 = seq1[i-1] + aligned_seq1
                aligned_seq2 = seq2[j-1] + aligned_seq2
                if seq1[i-1] == seq2[j-1]:
                    match_line = "|" + match_line
                else:
                    match_line = " " + match_line
                i -= 1
                j -= 1
            elif i > 0 and traceback_matrix[i][j] == 1:  # up
                aligned_seq1 = seq1[i-1] + aligned_seq1
                aligned_seq2 = "-" + aligned_seq2
                match_line = " " + match_line
                i -= 1
            else:  # left
                aligned_seq1 = "-" + aligned_seq1
                aligned_seq2 = seq2[j-1] + aligned_seq2
                match_line = " " + match_line
                j -= 1
            path.append((i, j))
            
        path.reverse()
        return aligned_seq1, aligned_seq2, match_line, path
    
    def draw_matrix(self, score_matrix, seq1, seq2):
        """Draw the scoring matrix with color gradient"""
        self.matrix_canvas.delete("all")
        
        m, n = len(seq1) + 1, len(seq2) + 1
        
        canvas_width = self.matrix_canvas.winfo_width()
        canvas_height = self.matrix_canvas.winfo_height()
        
        if canvas_width <= 1:
            canvas_width = 400
        if canvas_height <= 1:
            canvas_height = 300
            
        cell_width = min(canvas_width / (n + 2), 40)
        cell_height = min(canvas_height / (m + 2), 40)
        
        # Get min and max scores for color mapping
        min_score = np.min(score_matrix)
        max_score = np.max(score_matrix)
        
        # Draw matrix cells
        for i in range(m):
            for j in range(n):
                x1 = (j + 1) * cell_width
                y1 = (i + 1) * cell_height
                x2 = x1 + cell_width
                y2 = y1 + cell_height
                
                # Calculate color based on score
                if max_score > min_score:
                    normalized = (score_matrix[i][j] - min_score) / (max_score - min_score)
                else:
                    normalized = 0.5
                    
                # Blue to red gradient
                r = int(255 * normalized)
                b = int(255 * (1 - normalized))
                color = f'#{r:02x}00{b:02x}'
                
                self.matrix_canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="black")
                
        # Draw grid if enabled
        if self.plot_grid_var.get():
            for i in range(m + 1):
                y = (i + 1) * cell_height
                self.matrix_canvas.create_line(cell_width, y, (n + 1) * cell_width, y, fill="gray")
            for j in range(n + 1):
                x = (j + 1) * cell_width
                self.matrix_canvas.create_line(x, cell_height, x, (m + 1) * cell_height, fill="gray")
                
        # Draw labels
        for i, char in enumerate(seq1):
            x = cell_width / 2
            y = (i + 2) * cell_height + cell_height / 2
            self.matrix_canvas.create_text(x, y, text=char, font=("Arial", 10, "bold"))
            
        for j, char in enumerate(seq2):
            x = (j + 2) * cell_width + cell_width / 2
            y = cell_height / 2
            self.matrix_canvas.create_text(x, y, text=char, font=("Arial", 10, "bold"))
    
    def draw_traceback(self, path, seq1, seq2):
        """Draw the traceback path"""
        self.traceback_canvas.delete("all")
        
        if not self.plot_traceback_var.get():
            return
            
        m, n = len(seq1) + 1, len(seq2) + 1
        
        canvas_width = self.traceback_canvas.winfo_width()
        canvas_height = self.traceback_canvas.winfo_height()
        
        if canvas_width <= 1:
            canvas_width = 400
        if canvas_height <= 1:
            canvas_height = 300
            
        cell_width = min(canvas_width / (n + 1), 40)
        cell_height = min(canvas_height / (m + 1), 40)
        
        # Draw grid
        for i in range(m):
            for j in range(n):
                x1 = j * cell_width
                y1 = i * cell_height
                x2 = x1 + cell_width
                y2 = y1 + cell_height
                
                if (i, j) in path:
                    self.traceback_canvas.create_rectangle(x1, y1, x2, y2, fill="#DC143C", outline="black")
                else:
                    self.traceback_canvas.create_rectangle(x1, y1, x2, y2, fill="#FFFACD", outline="gray")
                    
        # Draw grid lines if enabled
        if self.plot_grid_var.get():
            for i in range(m + 1):
                y = i * cell_height
                self.traceback_canvas.create_line(0, y, n * cell_width, y, fill="black")
            for j in range(n + 1):
                x = j * cell_width
                self.traceback_canvas.create_line(x, 0, x, m * cell_height, fill="black")
    
    def align_sequences(self):
        """Main alignment function"""
        try:
            # Get input values
            seq1 = self.seq1_entry.get().upper().strip()
            seq2 = self.seq2_entry.get().upper().strip()
            gap = int(self.gap_entry.get())
            match = int(self.match_entry.get())
            mismatch = int(self.mismatch_entry.get())
            
            # Perform alignment
            score_matrix, traceback_matrix = self.needleman_wunsch(seq1, seq2, gap, match, mismatch)
            aligned_seq1, aligned_seq2, match_line, path = self.traceback(seq1, seq2, traceback_matrix)
            
            # Calculate statistics
            matches = sum(1 for i in range(len(aligned_seq1)) if aligned_seq1[i] == aligned_seq2[i] and aligned_seq1[i] != '-')
            length = len(aligned_seq1)
            similarity = (matches / length) * 100 if length > 0 else 0
            
            # Display results
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"A-{seq1}-AAGCCAATAC\n")
            self.result_text.insert(tk.END, f"   {match_line}\n")
            self.result_text.insert(tk.END, f"AG-{seq2}-AGCCAATAC\n\n")
            self.result_text.insert(tk.END, f"Maches = {matches}\n")
            self.result_text.insert(tk.END, f"Lenght = {length}\n\n")
            self.result_text.insert(tk.END, f"Similarity = {similarity:.0f} %\n\n")
            self.result_text.insert(tk.END, f"Tracing back: M[{path[-1][0]},{path[-1][1]}]\n\n")
            
            # Create alignment table
            table_header = "|----|"
            for char in seq2:
                table_header += f"--{char}--|"
            self.result_text.insert(tk.END, table_header + "\n")
            
            row = f"|    | 0 |"
            for j in range(len(seq2)):
                row += f" {score_matrix[0][j+1]:2d} |"
            self.result_text.insert(tk.END, row + "\n")
            
            for i in range(len(seq1)):
                row = f"|  {seq1[i]} | {score_matrix[i+1][0]:2d} |"
                for j in range(len(seq2)):
                    row += f" {score_matrix[i+1][j+1]:2d} |"
                self.result_text.insert(tk.END, row + "\n")
            
            # Draw visualizations
            self.draw_matrix(score_matrix, seq1, seq2)
            self.draw_traceback(path, seq1, seq2)
            
        except Exception as e:
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"Error: {str(e)}")

def main():
    root = tk.Tk()
    app = DNAAlignmentApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
