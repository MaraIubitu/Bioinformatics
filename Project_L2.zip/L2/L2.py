"""
Dinucleotide and Trinucleotide Percentage Calculator
This program calculates the percentage of all possible dinucleotide and trinucleotide 
combinations in a DNA sequence using a brute force approach.
"""

def generate_combinations(k):
    """
    Generate all possible k-nucleotide combinations (brute force).
    
    Args:
        k: Length of the combination (2 for dinucleotides, 3 for trinucleotides)
    
    Returns:
        List of all possible k-nucleotide combinations
    """
    nucleotides = ['A', 'C', 'G', 'T']
    combinations = []
    
    if k == 1:
        return nucleotides
    
    # Recursive brute force approach to generate all combinations
    def generate_recursive(current, remaining_length):
        if remaining_length == 0:
            combinations.append(current)
            return
        
        for nucleotide in nucleotides:
            generate_recursive(current + nucleotide, remaining_length - 1)
    
    generate_recursive("", k)
    return combinations


def count_occurrences(sequence, pattern):
    """
    Count how many times a pattern appears in the sequence.
    
    Args:
        sequence: The DNA sequence to search in
        pattern: The pattern to search for
    
    Returns:
        Number of occurrences
    """
    count = 0
    pattern_length = len(pattern)
    
    # Search through the sequence
    for i in range(len(sequence) - pattern_length + 1):
        if sequence[i:i + pattern_length] == pattern:
            count += 1
    
    return count


def calculate_percentages(sequence, k):
    """
    Calculate the percentage of each k-nucleotide combination in the sequence.
    
    Args:
        sequence: The DNA sequence to analyze
        k: Length of combinations (2 or 3)
    
    Returns:
        Dictionary with combinations as keys and percentages as values
    """
    combinations = generate_combinations(k)
    total_possible = len(sequence) - k + 1  # Total number of k-mers in the sequence
    
    results = {}
    for combination in combinations:
        count = count_occurrences(sequence, combination)
        percentage = (count / total_possible) * 100 if total_possible > 0 else 0
        results[combination] = {
            'count': count,
            'percentage': percentage
        }
    
    return results


def display_results(sequence, dinucleotide_results, trinucleotide_results):
    """
    Display the results in a formatted manner.
    """
    print("=" * 80)
    print("DNA SEQUENCE ANALYSIS")
    print("=" * 80)
    print(f"\nSequence: {sequence}")
    print(f"Length: {len(sequence)} nucleotides")
    print("=" * 80)
    
    # Display dinucleotide results
    print("\nDINUCLEOTIDE ANALYSIS:")
    print("-" * 80)
    print(f"{'Dinucleotide':<15} {'Count':<10} {'Percentage':<15}")
    print("-" * 80)
    
    # Sort by dinucleotide name for better readability
    for dinuc in sorted(dinucleotide_results.keys()):
        count = dinucleotide_results[dinuc]['count']
        percentage = dinucleotide_results[dinuc]['percentage']
        print(f"{dinuc:<15} {count:<10} {percentage:>6.2f}%")
    
    print("\n" + "=" * 80)
    
    # Display trinucleotide results
    print("\nTRINUCLEOTIDE ANALYSIS:")
    print("-" * 80)
    print(f"{'Trinucleotide':<15} {'Count':<10} {'Percentage':<15}")
    print("-" * 80)
    
    # Sort by trinucleotide name for better readability
    for trinuc in sorted(trinucleotide_results.keys()):
        count = trinucleotide_results[trinuc]['count']
        percentage = trinucleotide_results[trinuc]['percentage']
        print(f"{trinuc:<15} {count:<10} {percentage:>6.2f}%")
    
    print("=" * 80)
    
    # Summary statistics
    total_dinuc = sum(d['count'] for d in dinucleotide_results.values())
    total_trinuc = sum(t['count'] for t in trinucleotide_results.values())
    
    print("\nSUMMARY:")
    print(f"Total dinucleotides found: {total_dinuc}")
    print(f"Total trinucleotides found: {total_trinuc}")
    
    # Find most common
    most_common_dinuc = max(dinucleotide_results.items(), key=lambda x: x[1]['count'])
    most_common_trinuc = max(trinucleotide_results.items(), key=lambda x: x[1]['count'])
    
    print(f"\nMost common dinucleotide: {most_common_dinuc[0]} ({most_common_dinuc[1]['count']} occurrences, {most_common_dinuc[1]['percentage']:.2f}%)")
    print(f"Most common trinucleotide: {most_common_trinuc[0]} ({most_common_trinuc[1]['count']} occurrences, {most_common_trinuc[1]['percentage']:.2f}%)")
    print("=" * 80)


def main():
    """
    Main function to run the analysis.
    """
    # The DNA sequence to analyze
    S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"
    
    print("\nGenerating all dinucleotide combinations...")
    dinucleotide_results = calculate_percentages(S, 2)
    print(f"Generated {len(dinucleotide_results)} dinucleotide combinations")
    
    print("\nGenerating all trinucleotide combinations...")
    trinucleotide_results = calculate_percentages(S, 3)
    print(f"Generated {len(trinucleotide_results)} trinucleotide combinations")
    
    print("\nCalculating percentages...\n")
    
    # Display results
    display_results(S, dinucleotide_results, trinucleotide_results)


if __name__ == "__main__":
    main()
