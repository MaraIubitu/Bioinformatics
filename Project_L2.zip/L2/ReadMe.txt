Project L2 - Dinucleotide and Trinucleotide Analysis
====================================================

Author: Iubitu Mara, 1241EA

Description:
This project implements a brute force engine to generate all possible dinucleotide 
and trinucleotide combinations and calculates their percentage occurrence in a 
given DNA sequence.

Files Included:
- L2.py: Main Python source code
- ReadMe.txt: This file
- Screenshot.jpg: Output screenshot(s)

How to Run:
1. Ensure Python 3.x is installed on your system
2. Navigate to the project directory
3. Run: python L2.py

Features:
- Brute force generation of all 16 dinucleotide combinations (AA, AC, AG, AT, CA, CC, CG, CT, GA, GC, GG, GT, TA, TC, TG, TT)
- Brute force generation of all 64 trinucleotide combinations
- Percentage calculation for each combination
- Clear formatted output with statistics
- Summary of most common combinations

Sequence Analyzed:
TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA

Results Summary:
- Total dinucleotides analyzed: 56
- Total trinucleotides analyzed: 55
- Most common dinucleotide: CG (12.50%)
- Most common trinucleotide: ATC (7.27%)
