"""
DNA/RNA to Amino Acid Sequence Translator
Converts the coding region of a gene into an amino acid sequence using the genetic code.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

# Genetic Code Table (Codons to Amino Acids)
# Based on the standard genetic code
GENETIC_CODE = {
    # U (T in DNA)
    'UUU': 'Phe', 'UUC': 'Phe', 'UUA': 'Leu', 'UUG': 'Leu',
    'UCU': 'Ser', 'UCC': 'Ser', 'UCA': 'Ser', 'UCG': 'Ser',
    'UAU': 'Tyr', 'UAC': 'Tyr', 'UAA': 'Stop', 'UAG': 'Stop',
    'UGU': 'Cys', 'UGC': 'Cys', 'UGA': 'Stop', 'UGG': 'Trp',
    
    # C
    'CUU': 'Leu', 'CUC': 'Leu', 'CUA': 'Leu', 'CUG': 'Leu',
    'CCU': 'Pro', 'CCC': 'Pro', 'CCA': 'Pro', 'CCG': 'Pro',
    'CAU': 'His', 'CAC': 'His', 'CAA': 'Gln', 'CAG': 'Gln',
    'CGU': 'Arg', 'CGC': 'Arg', 'CGA': 'Arg', 'CGG': 'Arg',
    
    # A
    'AUU': 'Ile', 'AUC': 'Ile', 'AUA': 'Ile', 'AUG': 'Met',
    'ACU': 'Thr', 'ACC': 'Thr', 'ACA': 'Thr', 'ACG': 'Thr',
    'AAU': 'Asn', 'AAC': 'Asn', 'AAA': 'Lys', 'AAG': 'Lys',
    'AGU': 'Ser', 'AGC': 'Ser', 'AGA': 'Arg', 'AGG': 'Arg',
    
    # G
    'GUU': 'Val', 'GUC': 'Val', 'GUA': 'Val', 'GUG': 'Val',
    'GCU': 'Ala', 'GCC': 'Ala', 'GCA': 'Ala', 'GCG': 'Ala',
    'GAU': 'Asp', 'GAC': 'Asp', 'GAA': 'Glu', 'GAG': 'Glu',
    'GGU': 'Gly', 'GGC': 'Gly', 'GGA': 'Gly', 'GGG': 'Gly',
}

# Single letter amino acid codes
AA_SHORT = {
    'Phe': 'F', 'Leu': 'L', 'Ser': 'S', 'Tyr': 'Y', 'Cys': 'C',
    'Trp': 'W', 'Pro': 'P', 'His': 'H', 'Gln': 'Q', 'Arg': 'R',
    'Ile': 'I', 'Met': 'M', 'Thr': 'T', 'Asn': 'N', 'Lys': 'K',
    'Val': 'V', 'Ala': 'A', 'Asp': 'D', 'Glu': 'E', 'Gly': 'G',
    'Stop': '*'
}


def dna_to_rna(sequence):
    """Convert DNA sequence to RNA sequence (T -> U)"""
    return sequence.upper().replace('T', 'U')


def validate_sequence(sequence):
    """Validate that the sequence contains only valid nucleotides"""
    valid_dna = set('ATCG')
    valid_rna = set('AUCG')
    seq_upper = sequence.upper().replace(' ', '').replace('\n', '')
    
    # Check if it's DNA or RNA
    if all(base in valid_dna for base in seq_upper):
        return True, 'DNA'
    elif all(base in valid_rna for base in seq_upper):
        return True, 'RNA'
    else:
        return False, None


def translate_sequence(sequence, start_codon=True, output_format='3-letter'):
    """
    Translate DNA/RNA sequence to amino acid sequence
    
    Args:
        sequence: DNA or RNA sequence
        start_codon: If True, start translation from first AUG (Met)
        output_format: '3-letter' or '1-letter' amino acid codes
    
    Returns:
        amino_acid_sequence, details_dict
    """
    # Clean and validate sequence
    sequence = sequence.upper().replace(' ', '').replace('\n', '')
    is_valid, seq_type = validate_sequence(sequence)
    
    if not is_valid:
        raise ValueError("Invalid sequence! Only A, T/U, C, G are allowed.")
    
    # Convert to RNA if DNA
    if seq_type == 'DNA':
        rna_sequence = dna_to_rna(sequence)
    else:
        rna_sequence = sequence
    
    # Find start codon if requested
    start_pos = 0
    if start_codon:
        start_pos = rna_sequence.find('AUG')
        if start_pos == -1:
            raise ValueError("No start codon (AUG) found in sequence!")
    
    # Translate
    amino_acids = []
    codons_used = []
    
    for i in range(start_pos, len(rna_sequence) - 2, 3):
        codon = rna_sequence[i:i+3]
        
        if len(codon) == 3:
            aa = GENETIC_CODE.get(codon, '???')
            codons_used.append(codon)
            
            if aa == 'Stop':
                amino_acids.append(aa)
                break
            else:
                amino_acids.append(aa)
    
    # Format output
    if output_format == '1-letter':
        aa_sequence = ''.join([AA_SHORT.get(aa, '?') for aa in amino_acids])
    else:
        aa_sequence = '-'.join(amino_acids)
    
    details = {
        'original_sequence': sequence,
        'rna_sequence': rna_sequence,
        'start_position': start_pos,
        'codons': codons_used,
        'amino_acids': amino_acids,
        'length': len(amino_acids)
    }
    
    return aa_sequence, details


class GeneTranslatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("DNA/RNA to Protein Translator")
        self.root.geometry("800x700")
        
        # Configure style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Title
        title_frame = ttk.Frame(root, padding="10")
        title_frame.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        title_label = ttk.Label(title_frame, text="Gene to Protein Translator", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0)
        
        subtitle_label = ttk.Label(title_frame, 
                                   text="Convert DNA/RNA coding sequences to amino acid sequences",
                                   font=('Arial', 10))
        subtitle_label.grid(row=1, column=0)
        
        # Input Frame
        input_frame = ttk.LabelFrame(root, text="Input Sequence", padding="10")
        input_frame.grid(row=1, column=0, padx=10, pady=5, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        ttk.Label(input_frame, text="Enter DNA or RNA sequence:").grid(row=0, column=0, sticky=tk.W)
        
        self.input_text = scrolledtext.ScrolledText(input_frame, height=6, width=70, 
                                                    font=('Courier', 10))
        self.input_text.grid(row=1, column=0, columnspan=2, pady=5)
        
        # Options Frame
        options_frame = ttk.LabelFrame(root, text="Options", padding="10")
        options_frame.grid(row=2, column=0, padx=10, pady=5, sticky=(tk.W, tk.E))
        
        self.start_codon_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Start from first AUG codon (Met)", 
                       variable=self.start_codon_var).grid(row=0, column=0, sticky=tk.W)
        
        ttk.Label(options_frame, text="Output format:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.format_var = tk.StringVar(value='3-letter')
        ttk.Radiobutton(options_frame, text="3-letter (Phe-Leu-Ser...)", 
                       variable=self.format_var, value='3-letter').grid(row=1, column=1, sticky=tk.W)
        ttk.Radiobutton(options_frame, text="1-letter (FLS...)", 
                       variable=self.format_var, value='1-letter').grid(row=1, column=2, sticky=tk.W)
        
        # Buttons Frame
        button_frame = ttk.Frame(root, padding="10")
        button_frame.grid(row=3, column=0)
        
        ttk.Button(button_frame, text="Translate", command=self.translate).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="Clear All", command=self.clear_all).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="Load Example", command=self.load_example).grid(row=0, column=2, padx=5)
        
        # Output Frame
        output_frame = ttk.LabelFrame(root, text="Translation Results", padding="10")
        output_frame.grid(row=4, column=0, padx=10, pady=5, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.output_text = scrolledtext.ScrolledText(output_frame, height=15, width=70,
                                                     font=('Courier', 9))
        self.output_text.grid(row=0, column=0, pady=5)
        
        # Configure grid weights
        root.columnconfigure(0, weight=1)
        root.rowconfigure(4, weight=1)
    
    def translate(self):
        """Translate the input sequence"""
        sequence = self.input_text.get("1.0", tk.END).strip()
        
        if not sequence:
            messagebox.showwarning("Warning", "Please enter a sequence!")
            return
        
        try:
            aa_sequence, details = translate_sequence(
                sequence,
                start_codon=self.start_codon_var.get(),
                output_format=self.format_var.get()
            )
            
            # Display results
            output = "=" * 70 + "\n"
            output += "TRANSLATION RESULTS\n"
            output += "=" * 70 + "\n\n"
            
            output += f"Input Type: {validate_sequence(sequence)[1]}\n"
            output += f"Original Sequence ({len(details['original_sequence'])} bp):\n"
            output += self.format_sequence(details['original_sequence']) + "\n\n"
            
            if validate_sequence(sequence)[1] == 'DNA':
                output += f"RNA Sequence:\n"
                output += self.format_sequence(details['rna_sequence']) + "\n\n"
            
            output += f"Translation starts at position: {details['start_position'] + 1}\n\n"
            
            output += f"Codons ({len(details['codons'])}):\n"
            output += self.format_codons(details['codons']) + "\n\n"
            
            output += f"Amino Acid Sequence ({details['length']} amino acids):\n"
            output += aa_sequence + "\n\n"
            
            output += "Detailed Translation:\n"
            for i, (codon, aa) in enumerate(zip(details['codons'], details['amino_acids']), 1):
                short = AA_SHORT.get(aa, '?')
                output += f"{i:3d}. {codon} -> {aa:4s} ({short})\n"
            
            output += "\n" + "=" * 70 + "\n"
            
            self.output_text.delete("1.0", tk.END)
            self.output_text.insert("1.0", output)
            
        except Exception as e:
            messagebox.showerror("Error", str(e))
    
    def format_sequence(self, seq, width=60):
        """Format sequence for display"""
        lines = []
        for i in range(0, len(seq), width):
            lines.append(seq[i:i+width])
        return '\n'.join(lines)
    
    def format_codons(self, codons, per_line=15):
        """Format codons for display"""
        lines = []
        for i in range(0, len(codons), per_line):
            line_codons = codons[i:i+per_line]
            lines.append(' '.join(line_codons))
        return '\n'.join(lines)
    
    def clear_all(self):
        """Clear all text fields"""
        self.input_text.delete("1.0", tk.END)
        self.output_text.delete("1.0", tk.END)
    
    def load_example(self):
        """Load an example sequence"""
        # Example: Human insulin gene fragment
        example = "ATGGCCCTGTGGATGCGCCTCCTGCCCCTGCTGGCGCTGCTGGCCCTCTGGGGACCTGACCCAGCCGCAGCCTTTGTGAACCAACACCTGTGCGGCTCACACCTGGTGGAAGCTCTCTACCTAGTGTGCGGGGAACGAGGCTTCTTCTACACACCCAAGACCCGCCGGGAGGCAGAGGACCTGCAGGTGGGGCAGGTGGAGCTGGGCGGGGGCCCTGGTGCAGGCAGCCTGCAGCCCTTGGCCCTGGAGGGGTCCCTGCAGAAGCGTGGCATTGTGGAACAATGCTGTACCAGCATCTGCTCCCTCTACCAGCTGGAGAACTACTGCAACTAGACGCAGCCCGCAGGCAGCCCCACACCCGCCGCCTCCTGCACCGAGAGAGATGGAATAAAGCCCTTGAACCAGC"
        
        self.input_text.delete("1.0", tk.END)
        self.input_text.insert("1.0", example)
        messagebox.showinfo("Example Loaded", "Human insulin gene fragment loaded!")


def main():
    """Main function to run the application"""
    root = tk.Tk()
    app = GeneTranslatorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
