"""
Console version of DNA/RNA to Protein Translator
For command-line usage
"""

from L3 import translate_sequence, validate_sequence, AA_SHORT


def console_translator():
    """Console-based translator"""
    print("=" * 70)
    print("DNA/RNA to Protein Translator - Console Version")
    print("=" * 70)
    print()
    
    while True:
        print("\nEnter your DNA or RNA sequence (or 'quit' to exit):")
        sequence = input("> ").strip()
        
        if sequence.lower() in ['quit', 'exit', 'q']:
            print("Thank you for using the translator!")
            break
        
        if not sequence:
            print("Please enter a valid sequence.")
            continue
        
        try:
            # Get options
            print("\nOptions:")
            start_choice = input("Start from first AUG codon? (y/n, default=y): ").strip().lower()
            start_codon = start_choice != 'n'
            
            format_choice = input("Output format - 3-letter or 1-letter? (3/1, default=3): ").strip()
            output_format = '1-letter' if format_choice == '1' else '3-letter'
            
            # Translate
            aa_sequence, details = translate_sequence(sequence, start_codon, output_format)
            
            # Display results
            print("\n" + "=" * 70)
            print("TRANSLATION RESULTS")
            print("=" * 70)
            
            seq_type = validate_sequence(sequence)[1]
            print(f"\nInput Type: {seq_type}")
            print(f"Sequence Length: {len(details['original_sequence'])} bp")
            print(f"Translation starts at position: {details['start_position'] + 1}")
            print(f"Number of codons: {len(details['codons'])}")
            print(f"Number of amino acids: {details['length']}")
            
            print(f"\nAmino Acid Sequence:")
            print(aa_sequence)
            
            print(f"\nDetailed Translation:")
            for i, (codon, aa) in enumerate(zip(details['codons'], details['amino_acids']), 1):
                short = AA_SHORT.get(aa, '?')
                print(f"{i:3d}. {codon} -> {aa:4s} ({short})")
            
            print("\n" + "=" * 70)
            
            another = input("\nTranslate another sequence? (y/n): ").strip().lower()
            if another == 'n':
                print("Thank you for using the translator!")
                break
                
        except Exception as e:
            print(f"\nError: {e}")
            print("Please try again with a valid sequence.")


if __name__ == "__main__":
    console_translator()
