DNA/RNA to Protein Translator - Project L4
==========================================

Author: Iubitu Mara, 1241EA


Description:
------------
This application converts the coding region of a gene (DNA or RNA sequence) into an amino acid sequence using the standard genetic code.

Features:
---------
- Accepts both DNA and RNA sequences
- Automatic DNA to RNA conversion
- Start codon detection (AUG/Met)
- Option to start translation from first AUG or from beginning
- Two output formats: 3-letter codes (Phe-Leu-Ser) or 1-letter codes (FLS)
- Detailed translation output showing:
  * Original sequence
  * RNA sequence (if input was DNA)
  * Codons used
  * Amino acid sequence
  * Codon-by-codon translation details
- User-friendly GUI with example sequence loader

How to Run:
-----------
1. Make sure Python 3.x is installed on your system
2. Run the application:
   python L3.py

3. Enter or paste your DNA/RNA sequence in the input box
4. Select your options:
   - Check "Start from first AUG codon" to begin translation at the start codon
   - Choose output format (3-letter or 1-letter amino acid codes)
5. Click "Translate" to see the results

Genetic Code:
-------------
The application uses the standard genetic code table with:
- 64 codons (triplets of nucleotides)
- 20 amino acids
- 3 stop codons (UAA, UAG, UGA)
- 1 start codon (AUG - Methionine)

Example Usage:
--------------
Click "Load Example" to load a sample sequence (human insulin gene fragment)

Requirements:
-------------
- Python 3.x
- tkinter (usually included with Python)

File Structure:
---------------
- L3.py: Main application source code
- ReadMe.txt: This file
- Screenshot.jpg: GUI screenshot(s)
