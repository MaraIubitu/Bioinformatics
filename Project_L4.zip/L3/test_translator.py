"""
Test script for DNA/RNA to Protein Translator
Demonstrates various test cases
"""

from L3 import translate_sequence, GENETIC_CODE


def run_tests():
    """Run various test cases"""
    
    print("=" * 80)
    print("DNA/RNA to Protein Translator - Test Cases")
    print("=" * 80)
    
    # Test Case 1: Simple DNA sequence
    print("\n--- Test Case 1: Simple DNA Sequence ---")
    dna1 = "ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG"
    print(f"Input: {dna1}")
    try:
        result, details = translate_sequence(dna1, start_codon=True, output_format='3-letter')
        print(f"Result: {result}")
        print(f"Codons: {' '.join(details['codons'])}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test Case 2: RNA sequence
    print("\n--- Test Case 2: RNA Sequence ---")
    rna1 = "AUGGCCAUUGUAAUGGGCCGCUGAAAGGGUGCCCGAUAG"
    print(f"Input: {rna1}")
    try:
        result, details = translate_sequence(rna1, start_codon=True, output_format='1-letter')
        print(f"Result: {result}")
        print(f"Codons: {' '.join(details['codons'])}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test Case 3: Sequence with stop codon
    print("\n--- Test Case 3: Sequence with Stop Codon ---")
    dna2 = "ATGAAATTTAAAGCCTAG"
    print(f"Input: {dna2}")
    try:
        result, details = translate_sequence(dna2, start_codon=True, output_format='3-letter')
        print(f"Result: {result}")
        print(f"Amino Acids: {details['amino_acids']}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test Case 4: Without start codon requirement
    print("\n--- Test Case 4: Translation without Start Codon Requirement ---")
    dna3 = "TTTTCATCGTCATAA"
    print(f"Input: {dna3}")
    try:
        result, details = translate_sequence(dna3, start_codon=False, output_format='3-letter')
        print(f"Result: {result}")
        print(f"Codons: {' '.join(details['codons'])}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test Case 5: All amino acids demonstration
    print("\n--- Test Case 5: Demonstrating Various Amino Acids ---")
    # Create a sequence that codes for various amino acids
    demo_codons = ['AUG', 'UUU', 'CCC', 'GGG', 'AAA', 'CAC', 'GUU', 'UAU', 'UGG', 'UAA']
    demo_rna = ''.join(demo_codons)
    print(f"Input: {demo_rna}")
    print(f"Codons: {' '.join(demo_codons)}")
    try:
        result, details = translate_sequence(demo_rna, start_codon=True, output_format='3-letter')
        print(f"Result: {result}")
        for codon, aa in zip(details['codons'], details['amino_acids']):
            print(f"  {codon} -> {aa}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test Case 6: Longer sequence (insulin gene fragment)
    print("\n--- Test Case 6: Human Insulin Gene Fragment ---")
    insulin = "ATGGCCCTGTGGATGCGCCTCCTGCCCCTGCTGGCGCTGCTGGCCCTCTGGGGACCTGACCCAGCCGCAGCCTTTGTGAACCAACACCTGTGC"
    print(f"Input: {insulin[:50]}... (length: {len(insulin)} bp)")
    try:
        result, details = translate_sequence(insulin, start_codon=True, output_format='1-letter')
        print(f"Result: {result}")
        print(f"Number of amino acids: {len(details['amino_acids'])}")
        print(f"First 5 codons: {' '.join(details['codons'][:5])}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Genetic code verification
    print("\n--- Genetic Code Table Verification ---")
    print(f"Total codons in genetic code: {len(GENETIC_CODE)}")
    stop_codons = [codon for codon, aa in GENETIC_CODE.items() if aa == 'Stop']
    print(f"Stop codons: {', '.join(stop_codons)}")
    start_codons = [codon for codon, aa in GENETIC_CODE.items() if aa == 'Met']
    print(f"Start codons (Met): {', '.join(start_codons)}")
    
    print("\n" + "=" * 80)
    print("All tests completed!")
    print("=" * 80)


if __name__ == "__main__":
    run_tests()
