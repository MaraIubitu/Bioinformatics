"""
Restriction Enzyme Digestion Simulator with Gel Electrophoresis Visualization
Simulates DNA digestion by restriction enzymes and visualizes results on a virtual gel
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import math

# Restriction Enzymes Database
# Format: {name: (recognition_site, cut_position_from_start)}
RESTRICTION_ENZYMES = {
    'EcoRI': {
        'recognition': 'GAATTC',
        'cut_position': 1,  # Cut after position 1: G^AATTC
        'description': "5'---G     AATTC---3'\n3'---CTTAA     G---5'"
    },
    'BamHI': {
        'recognition': 'GGATCC',
        'cut_position': 1,  # Cut after position 1: G^GATCC
        'description': "5'---G     GATCC---3'\n3'---CCTAG     G---5'"
    },
    'HindIII': {
        'recognition': 'AAGCTT',
        'cut_position': 1,  # Cut after position 1: A^AGCTT
        'description': "5'---A     AGCTT---3'\n3'---TTCGA     A---5'"
    },
    'TaqI': {
        'recognition': 'TCGA',
        'cut_position': 1,  # Cut after position 1: T^CGA
        'description': "5'---T   CGA---3'\n3'---AGC   T---5'"
    },
    'HaeIII': {
        'recognition': 'GGCC',
        'cut_position': 2,  # Cut in middle: GG^CC
        'description': "5'---GG  CC---3'\n3'---CC  GG---5'"
    }
}

# Sample DNA sequence from NCBI - E. coli lac operon region (truncated to ~1500 bp)
SAMPLE_DNA = """ATGACCATGATTACGGATTCACTGGCCGTCGTTTTACAACGTCGTGACTGGGAAAACCCTGGCGTTACCCAACTTAATCGCCTTGCAGCACATCCCCCTTTCGCCAGCTGGCGTAATAGCGAAGAGGCCCGCACCGATCGCCCTTCCCAACAGTTGCGCAGCCTGAATGGCGAATGGCGCTTTGCCTGGTTTCCGGCACCAGAAGCGGTGCCGGAAAGCTGGCTGGAGTGCGATCTTCCTGAGGCCGATACTGTCGTCGTCCCCTCAAACTGGCAGATGCACGGTTACGATGCGCCCATCTACACCAACGTAACCTATCCCATTACGGTCAATCCGCCGTTTGTTCCCACGGAGAATCCGACGGGTTGTTACTCGCTCACATTTAATGTTGATGAAAGCTGGCTACAGGAAGGCCAGACGCGAATTATTTTTGATGGCGTTCCTATTGGTTAAAAAATGAGCTGATTTAACAAAAATTTAATGCGAATTTTAACAAAATATTAACGTTTACAATTTAAATATTTGCTTATACAATCTTCCTGTTTTTGGGGCTTTTCTGATTATCAACCGGGGTACATATGATTGACATGCTAGTTTTACGATTACCGTTCATCGATTCTCTTGTTTGCTCCAGACTCTCAGGCAATGACCTGATAGCCTTTGTAGATCTCTCAAAAATAGCTACCCTCTCCGGCATTAATTTATCAGCTAGAACGGTTGAATATCATATTGATGGTGATTTGACTGTCTCCGGCCTTTCTCACCCTTTTGAATCTTTACCTACACATTACTCAGGCATTGCATTTAAAATATATGAGGGTTCTAAAAATTTTTATCCTTGCGTTGAAATAAAGGCTTCTCCCGCAAAAGTATTACAGGGTCATAATGTTTTTGGTACAACCGATTTAGCTTTATGCTCTGAGGCTTTATTGCTTAATTTTGCTAATTCTTTGCCTTGCCTGTATGATTTATTGGATGTTAATGCTACTACTATTAGTAGAATTGATGCCACCTTTTCAGCTCGCGCCCCAAATGAAAATATAGCTAAACAGGTTATTGACCATTTGCGAAATGTATCTAATGGTCAAACTAAATCTACTCGTTCGCAGAATTGGGAATCAACTGTTATATGGAATGAAACTTCCAGACACCGTACTTTAGTTGCATATTTAAAACATGTTGAGCTACAGCATTATATTCAGCAATTAAGCTCTAAGCCATCCGCAAAAATGACCTCTTATCAAAAGGAGCAATTAAAGGTACTCTCTAATCCTGACCTGTTGGAGTTTGCTTCCGGTCTGGTTCGCTTTGAAGCTCGAATTAAAACGCGATATTTGAAGTCTTTCGGGCTTCCTCTTAATCTTTTTGATGCAATCCGCTTTGCTTCTGACTATAATAGTCAGGGTAAAGACCTGATTTTTGATTTATGGTCATTCTCGTTTTCTGAACTGTTTAAAGCATTTGAGGGGGATTCAATGAATATTTATGACGATTCCGCAGTATTGGACGCTATCCAGTCTAAACATTTTACTATTACCCCCTCTGGCAAAACTTCTTTTGCAAAAGCCTCTCGCTATTTTGGTTTTTATCGTCGTCTGGTAAACGAGGGTTATGATAGTGTTGCTCTTACTATGCCTCGTAATTCCTTTTGGCGTTATGTATCTGCATTAGTTGAATGTGGTATTCCTAAATCTCAACTGATGAATCTTTCTACCTGTAATAATGTTGTTCCGTTAGTTCGTTTTATTAACGTAGATTTTTCTTCCCAACGTCCTGACTGGTATAATGAGCCAGTTCTTAAAATCGCATAAGGTAATTCACAATGATTAAAGTTGAAATTAAACCATCTCAAGCCCAATTTACTACTCGTTCTGGTGTTTCTCGTCAGGGCAAGCCTTATTCACTGAATGAGCAGCTTTGTTACGTTGATTTGGGTAATGAATATCCGGTTCTTGTCAAGATTACTCTTGATGAAGGTCAGCCAGCCTATGCGCCTGGTCTGTACACCGTTCATCTGTCCTCTTTCAAAGTTGGTCAGTTCGGTTCCCTTATGATTGACCGTCTGCGCCTCGTTCCGGCTAAGTAACATGGAGCAGGTCGCGGATTTCGACACAATTTATCAGGCGATGATACAAATCTCCGTTGTACTTTGTTTCGCGCTTGGTATAATCGCTGGGGGTCAAAGATGAGTGTTTTAGTGTATTCTTTTGCCTCTTTCGTTTTAGGTTGGTGCCTTCGTAGTGGCATTACGTATTTTACCCGTTTAATGGAAACTTCCTCATGAAAAAGTCTTTAGTCCTCAAAGCCTCTGTAGCCGTTGCTACCCTCGTTCCGATGCTGTCTTTCGCTGCTGAGGGTGACGATCCCGCAAAAGCGGCCTTTAACTCCCTGCAAGCCTCAGCGACCGAATATATCGGTTATGCGTGGGCGATGGTTGTTGTCATTGTCGGCGCAACTATCGGTATCAAGCTGTTTAAGAAATTCACCTCGAAAGCAAGCTGATAAACCGATACAATTAAAGGCTCCTTTTGGAGCCTTTTTTTTGGAGATTTTCAACGTGAAAAAATTATTATTCGCAATTCCTTTAGTTGTTCCTTTCTATTCTCACTCCGCTGAAACTGTTGAAAGTTGTTTAGCAAAATCCCATACAGAAAATTCATTTACTAACGTCTGGAAAGACGACAAAACTTTAGATCGTTACGCTAACTATGAGGGCTGTCTGTGGAATGCTACAGGCGTTGTAGTTTGTACTGGTGACGAAACTCAGTGTTACGGTACATGGGTTCCTATTGGGCTTGCTATCCCTGAAAATGAGGGTGGTGGCTCTGAGGGTGGCGGTTCTGAGGGTGGCGGTTCTGAGGGTGGCGGTACTAAACCTCCTGAGTACGGTGATACACCTATTCCGGGCTATACTTATATCAACCCTCTCGACGGCACTTATCCGCCTGGTACTGAGCAAAACCCCGCTAATCCTAATCCTTCTCTTGAGGAGTCTCAGCCTCTTAATACTTTCATGTTTCAGAATAATAGGTTCCGAAATAGGCAGGGGGCATTAACTGTTTATACGGGCACTGTTACTCAAGGCACTGACCCCGTTAAAACTTATTACCAGTACACTCCTGTATCATCAAAAGCCATGTATGACGCTTACTGGAACGGTAAATTCAGAGACTGCGCTTTCCATTCTGGCTTTAATGAGGATTTATTTGTTTGTGAATATCAAGGCCAATCGTCTGACCTGCCTCAACCTCCTGTCAATGCTGGCGGCGGCTCTGGTGGTGGTTCTGGTGGCGGCTCTGAGGGTGGTGGCTCTGAGGGTGGCGGTTCTGAGGGTGGCGGCTCTGAGGGAGGCGGTTCCGGTGGTGGCTCTGGTTCCGGTGATTTTGATTATGAAAAGATGGCAAACGCTAATAAGGGGGCTATGACCGAAAATGCCGATGAAAACGCGCTACAGTCTGACGCTAAAGGCAAACTTGATTCTGTCGCTACTGATTACGGTGCTGCTATCGATGGTTTCATTGGTGACGTTTCCGGCCTTGCTAATGGTAATGGTGCTACTGGTGATTTTGCTGGCTCTAATTCCCAAATGGCTCAAGTCGGTGACGGTGATAATTCACCTTTAATGAATAATTTCCGTCAATATTTACCTTCCCTCCCTCAATCGGTTGAATGTCGCCCTTTTGTCTTTGGCGCTGGTAAACCATATGAATTTTCTATTGATTGTGACAAAATAAACTTATTCCGTGGTGTCTTTGCGTTTCTTTTATATGTTGCCACCTTTATGTATGTATTTTCTACGTTTGCTAACATACTGCGTAATAAGGAGTCTTAATCATGCCAGTTCTTTTGGGTATTCCGTTATTATTGCGTTTCCTCGGTTTCCTTCTGGTAACTTTGTTCGGCTATCTGCTTACTTTTCTTAAAAAGGGCTTCGGTAAGATAGCTATTGCTATTTCATTGTTTCTTGCTCTTATTATTGGGCTTAACTCAATTCTTGTGGGTTATCTCTCTGATATTAGCGCTCAATTACCCTCTGACTTTGTTCAGGGTGTTCAGTTAATTCTCCCGTCTAATGCGCTTCCCTGTTTTTATGTTATTCTCTCTGTAAAGGCTGCTATTTTCATTTTTGACGTTAAACAAAAAATCGTTTCTTATTTGGATTGGGATAAATAATATGGCTGTTTATTTTGTAACTGGCAAATTAGGCTCTGGAAAGACGCTCGTTAGCGTTGGTAAGATTCAGGATAAAATTGTAGCTGGGTGCAAAATAGCAACTAATCTTGATTTAAGGCTTCAAAACCTCCCGCAAGTCGGGAGGTTCGCTAAAACGCCTCGCGTTCTTAGAATACCGGATAAGCCTTCTATATCTGATTTGCTTGCTATTGGGCGCGGTAATGATTCCTACGATGAAAATAAAAACGGCTTGCTTGTTCTCGATGAGTGCGGTACTTGGTTTAATACCCGTTCTTGGAATGATAAGGAAAGACAGCCGATTATTGATTGGTTTCTACATGCTCGTAAATTAGGATGGGATATTATTTTTCTTGTTCAGGACTTATCTATTGTTGATAAACAGGCGCGTTCTGCATTAGCTGAACATGTTGTTTATTGTCGTCGTCTGGACAGAATTACTTTACCTTTTGTCGGTACTTTATATTCTCTTATTACTGGCTCGAAAATGCCTCTGCCTAAATTACATGTTGGCGTTGTTAAATATGGCGATTCTCAATTAAGCCCTACTGTTGAGCGTTGGCTTTATACTGGTAAGAATTTGTATAACGCATATGATACTAAACAGGCTTTTTCTAGTAATTATGATTCCGGTGTTTATTCTTATTTAACGCCTTATTTATCACACGGTCGGTATTTCAAACCATTAAATTTAGGTCAGAAGATGAAATTAACTAAAATATATTTGAAAAAGTTTTCTCGCGTTCTTTGTCTTGCGATTGGATTTGCATCAGCATTTACATATAGTTATATAACCCAACCTAAGCCGGAGGTTAAAAAGGTAGTCTCTCAGACCTATGATTTTGATAAATTCACTATTGACTCTTCTCAGCGTCTTAATCTAAGCTATCGCTATGTTTTCAAGGATTCTAAGGGAAAATTAATTAATAGCGACGATTTACAGAAGCAAGGTTATTCACTCACATATATTGATTTATGTACTGTTTCCATTAAAAAAGGTAATTCAAATGAAATTGTTAAATGTAATTAATTTTGTTTTCTTGATGTTTGTTTCATCATCTTCTTTTGCTCAGGTAATTGAAATGAATAATTCGCCTCTGCGCGATTTTGTAACTTGGTATTCAAAGCAATCAGGCGAATCCGTTATTGTTTCTCCCGATGTAAAAGGTACTGTTACTGTATATTCATCTGACGTTAAACCTGAAAATCTACGCAATTTCTTTATTTCTGTTTTACGTGCAAATAATTTTGATATGGTAGGTTCTAACCCTTCCATTATTCAGAAGTATAATCCAAACAATCAGGATTATATTGATGAATTGCCATCATCTGATAATCAGGAATATGATGATAATTCCGCTCCTTCTGGTGGTTTCTTTGTTCCGCAAAATGATAATGTTACTCAAACTTTTAAAATTAATAACGTTCGGGCAAAGGATTTAATACGAGTTGTCGAATTGTTTGTAAAGTCTAATACTTCTAAATCCTCAAATGTATTATCTATTGACGGCTCTAATCTATTAGTTGTTAGTGCTCCTAAAGATATTTTAGATAACCTTCCTCAATTCCTTTCAACTGTTGATTTGCCAACTGACCAGATATTGATTGAGGGTTTGATATTTGAGGTTCAGCAAGGTGATGCTTTAGATTTTTCATTTGCTGCTGGCTCTCAGCGTGGCACTGTTGCAGGCGGTGTTAATACTGACCGCCTCACCTCTGTTTTATCTTCTGCTGGTGGTTCGTTCGGTATTTTTAATGGCGATGTTTTAGGGCTATCAGTTCGCGCATTAAAGACTAATAGCCATTCAAAAATATTGTCTGTGCCACGTATTCTTACGCTTTCAGGTCAGAAGGGTTCTATCTCTGTTGGCCAGAATGTCCCTTTTATTACTGGTCGTGTGACTGGTGAATCTGCCAATGTAAATAATCCATTTCAGACGATTGAGCGTCAAAATGTAGGTATTTCCATGAGCGTTTTTCCTGTTGCAATGGCTGGCGGTAATATTGTTCTGGATATTACCAGCAAGGCCGATAGTTTGAGTTCTTCTACTCAGGCAAGTGATGTTATTACTAATCAAAGAAGTATTGCTACAACGGTTAATTTGCGTGATGGACAGACTCTTTTACTCGGTGGCCTCACTGATTATAAAAACACTTCTCAGGATTCTGGCGTACCGTTCCTGTCTAAAATCCCTTTAATCGGCCTCCTGTTTAGCTCCCGCTCTGATTCTAACGAGGAAAGCACGTTATACGTGCTCGTCAAAGCAACCATAGTACGCGCCCTGTAGCGGCGCATTAAGCGCGGCGGGTGTGGTGGTTACGCGCAGCGTGACCGCTACACTTGCCAGCGCCCTAGCGCCCGCTCCTTTCGCTTTCTTCCCTTCCTTTCTCGCCACGTTCGCCGGCTTTCCCCGTCAAGCTCTAAATCGGGGGCTCCCTTTAGGGTTCCGATTTAGTGCTTTACGGCACCTCGACCCCAAAAAACTTGATTAGGGTGATGGTTCACGTAGTGGGCCATCGCCCTGATAGACGGTTTTTCGCCCTTTGACGTTGGAGTCCACGTTCTTTAATAGTGGACTCTTGTTCCAAACTGGAACAACACTCAACCCTATCTCGGTCTATTCTTTTGATTTATAAGGGATTTTGCCGATTTCGGCCTATTGGTTAAAAAATGAGCTGATTTAACAAAAATTTAACGCGAATTTTAACAAAATATTAACGTTTACAATTTCCTGATGCGGTATTTTCTCCTTACGCATCTGTGCGGTATTTCACACCGCATAGATCGGCAAGTGCACAAACAATACTTAAATAAATACTACTCAGTAATAACCTATTTCTTAGCATTTTTGACGAAATTTGCTATTTTGTTAGAGTCTTTTACACCATTTGTCTCCACACCTCCGCTTACATCAACACCAATAACGCCATTTAATCTAAGCGCATCACCAACATTTTCTGGCGTCAGTCCACCAGCTAACATAAAATGTAAGCTTTCGGGGCTCTCTTGCCTTCCAACCCAGTCAGAAATCGAGTTCCAATCCAAAAGTTCACCTGTCCCACCTGCTTCTGAATCAAACAAGGGAATAAACGAATGAGGTTTCTGTGAAGCTGCACTGAGTAGTATGTTGCAGTCTTTTGGAAATACGAGTCTTTTAATAACTGGCAAACCGAGGAACTCTTGGTATTCTTGCCACGACTCATCTCCATGCAGTTGGACGATATCAATGCCGTAATCATTGACCAGAGCCAAAACATCCTCCTTAG"""


class RestrictionEnzymeSimulator:
    """Core class for restriction enzyme digestion simulation"""
    
    def __init__(self, dna_sequence):
        """Initialize with DNA sequence"""
        self.dna_sequence = dna_sequence.upper().replace(' ', '').replace('\n', '')
        self.validate_sequence()
    
    def validate_sequence(self):
        """Validate DNA sequence"""
        valid_bases = set('ATCG')
        if not all(base in valid_bases for base in self.dna_sequence):
            raise ValueError("Invalid DNA sequence! Only A, T, C, G are allowed.")
        if len(self.dna_sequence) < 100:
            raise ValueError("DNA sequence too short! Minimum 100 bp required.")
    
    def find_restriction_sites(self, enzyme_name):
        """
        Find all restriction sites for a given enzyme
        Returns: list of cut positions
        """
        enzyme = RESTRICTION_ENZYMES[enzyme_name]
        recognition_site = enzyme['recognition']
        cut_position_offset = enzyme['cut_position']
        
        cut_sites = []
        seq = self.dna_sequence
        
        # Find all occurrences of recognition site
        start = 0
        while True:
            pos = seq.find(recognition_site, start)
            if pos == -1:
                break
            # Calculate actual cut position
            cut_pos = pos + cut_position_offset
            cut_sites.append(cut_pos)
            start = pos + 1
        
        return sorted(cut_sites)
    
    def digest(self, enzyme_names):
        """
        Digest DNA with multiple enzymes
        Returns: dictionary with results for each enzyme
        """
        results = {}
        
        for enzyme_name in enzyme_names:
            if enzyme_name not in RESTRICTION_ENZYMES:
                continue
            
            cut_sites = self.find_restriction_sites(enzyme_name)
            fragments = self.calculate_fragments(cut_sites)
            
            results[enzyme_name] = {
                'cut_sites': cut_sites,
                'num_cuts': len(cut_sites),
                'fragments': fragments,
                'recognition': RESTRICTION_ENZYMES[enzyme_name]['recognition']
            }
        
        return results
    
    def calculate_fragments(self, cut_sites):
        """
        Calculate fragment lengths from cut positions
        Returns: list of (start, end, length) tuples
        """
        if not cut_sites:
            # No cuts, whole sequence is one fragment
            return [(0, len(self.dna_sequence), len(self.dna_sequence))]
        
        fragments = []
        positions = [0] + cut_sites + [len(self.dna_sequence)]
        
        for i in range(len(positions) - 1):
            start = positions[i]
            end = positions[i + 1]
            length = end - start
            fragments.append((start, end, length))
        
        return sorted(fragments, key=lambda x: x[2], reverse=True)


class GelElectrophoresisCanvas(tk.Canvas):
    """Canvas for drawing gel electrophoresis simulation"""
    
    def __init__(self, parent, width=700, height=500):
        super().__init__(parent, width=width, height=height, bg='black')
        self.width = width
        self.height = height
        self.lanes = []
        self.ladder_shown = True
    
    def draw_gel(self, results, show_ladder=True):
        """Draw the gel electrophoresis visualization"""
        self.delete('all')
        self.lanes = []
        
        # Gel background
        gel_margin = 50
        gel_width = self.width - 2 * gel_margin
        gel_height = self.height - 2 * gel_margin
        
        # Draw gel background (darker gray)
        self.create_rectangle(gel_margin, gel_margin, 
                            self.width - gel_margin, self.height - gel_margin,
                            fill='#2a2a2a', outline='#555555', width=2)
        
        # Calculate lanes
        num_enzymes = len(results)
        num_lanes = num_enzymes + (1 if show_ladder else 0)
        
        if num_lanes == 0:
            return
        
        lane_width = gel_width / num_lanes
        
        # Draw wells at top
        well_y = gel_margin + 20
        well_height = 15
        
        lane_x = gel_margin
        
        # Draw ladder lane if enabled
        if show_ladder:
            self.draw_well(lane_x, well_y, lane_width, well_height, "Ladder")
            self.draw_ladder_lane(lane_x, lane_width, gel_margin, gel_height)
            lane_x += lane_width
        
        # Draw enzyme lanes
        for enzyme_name, data in results.items():
            self.draw_well(lane_x, well_y, lane_width, well_height, enzyme_name)
            self.draw_enzyme_lane(lane_x, lane_width, gel_margin, gel_height, data)
            lane_x += lane_width
    
    def draw_well(self, x, y, width, height, label):
        """Draw a single well"""
        well_width = width * 0.7
        well_x = x + (width - well_width) / 2
        
        # Well
        self.create_rectangle(well_x, y, well_x + well_width, y + height,
                            fill='#1a1a1a', outline='#666666', width=1)
        
        # Label above well
        self.create_text(x + width/2, y - 10, text=label, 
                        fill='white', font=('Arial', 8, 'bold'))
    
    def draw_ladder_lane(self, x, width, margin, gel_height):
        """Draw DNA ladder (standard sizes)"""
        # Common ladder sizes in bp
        ladder_sizes = [10000, 8000, 6000, 5000, 4000, 3000, 2500, 2000, 
                       1500, 1000, 750, 500, 250]
        
        lane_center = x + width / 2
        band_width = width * 0.6
        
        for size in ladder_sizes:
            y_pos = self.calculate_band_position(size, margin, gel_height)
            intensity = min(200, 100 + size // 50)  # Brighter for larger fragments
            color = f'#{intensity:02x}{intensity:02x}ff'
            
            self.create_rectangle(lane_center - band_width/2, y_pos - 2,
                                lane_center + band_width/2, y_pos + 2,
                                fill=color, outline=color)
            
            # Size label
            if size >= 1000:
                label = f"{size//1000}kb"
            else:
                label = f"{size}bp"
            self.create_text(margin - 25, y_pos, text=label,
                           fill='white', font=('Arial', 7), anchor='e')
    
    def draw_enzyme_lane(self, x, width, margin, gel_height, data):
        """Draw bands for enzyme digestion results"""
        fragments = data['fragments']
        lane_center = x + width / 2
        band_width = width * 0.6
        
        if not fragments:
            return
        
        # Draw each fragment as a band
        for start, end, length in fragments:
            y_pos = self.calculate_band_position(length, margin, gel_height)
            
            # Band intensity based on size (larger = brighter)
            intensity = min(220, 120 + length // 20)
            color = f'#{intensity:02x}ff{intensity:02x}'
            
            # Band thickness based on relative amount
            band_height = 3
            
            self.create_rectangle(lane_center - band_width/2, y_pos - band_height,
                                lane_center + band_width/2, y_pos + band_height,
                                fill=color, outline=color)
            
            # Size label next to band
            if length >= 1000:
                label = f"{length//1000}kb"
            else:
                label = f"{length}bp"
            self.create_text(x + width + 5, y_pos, text=label,
                           fill='yellow', font=('Arial', 7), anchor='w')
    
    def calculate_band_position(self, fragment_size, margin, gel_height):
        """
        Calculate Y position for a fragment based on size
        Uses logarithmic scale like real gel electrophoresis
        Smaller fragments travel further (higher Y value)
        """
        # Logarithmic migration
        max_size = 10000
        min_size = 100
        
        if fragment_size > max_size:
            fragment_size = max_size
        if fragment_size < min_size:
            fragment_size = min_size
        
        # Logarithmic scale
        log_size = math.log10(fragment_size)
        log_max = math.log10(max_size)
        log_min = math.log10(min_size)
        
        # Normalize to 0-1 range (inverted: larger = closer to top)
        normalized = (log_max - log_size) / (log_max - log_min)
        
        # Map to gel position (leave space at top and bottom)
        usable_height = gel_height - 100
        y_pos = margin + 60 + (normalized * usable_height)
        
        return y_pos


class RestrictionEnzymeGUI:
    """Main GUI application"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Restriction Enzyme Digestion Simulator")
        self.root.geometry("900x800")
        
        # Configure style
        style = ttk.Style()
        style.theme_use('clam')
        
        self.create_widgets()
        self.load_sample_sequence()
    
    def create_widgets(self):
        """Create GUI widgets"""
        
        # Title
        title_frame = ttk.Frame(self.root, padding="10")
        title_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E))
        
        title_label = ttk.Label(title_frame, 
                               text="Restriction Enzyme Digestion Simulator",
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0)
        
        subtitle_label = ttk.Label(title_frame,
                                  text="Virtual Gel Electrophoresis",
                                  font=('Arial', 10))
        subtitle_label.grid(row=1, column=0)
        
        # Left panel - Input and controls
        left_panel = ttk.Frame(self.root, padding="5")
        left_panel.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        # DNA Sequence Input
        seq_frame = ttk.LabelFrame(left_panel, text="DNA Sequence", padding="10")
        seq_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        ttk.Label(seq_frame, text=f"Enter DNA sequence (100-10000 bp):").grid(
            row=0, column=0, sticky=tk.W)
        
        self.seq_text = scrolledtext.ScrolledText(seq_frame, height=8, width=45,
                                                  font=('Courier', 9))
        self.seq_text.grid(row=1, column=0, pady=5)
        
        # Sequence info
        self.seq_info_label = ttk.Label(seq_frame, text="Length: 0 bp",
                                       font=('Arial', 9))
        self.seq_info_label.grid(row=2, column=0, sticky=tk.W)
        
        # Enzyme Selection
        enzyme_frame = ttk.LabelFrame(left_panel, text="Restriction Enzymes",
                                     padding="10")
        enzyme_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(enzyme_frame, text="Select enzymes to use:").grid(
            row=0, column=0, sticky=tk.W, columnspan=2)
        
        self.enzyme_vars = {}
        row = 1
        for enzyme_name, enzyme_data in RESTRICTION_ENZYMES.items():
            var = tk.BooleanVar(value=True)
            self.enzyme_vars[enzyme_name] = var
            
            cb = ttk.Checkbutton(enzyme_frame, text=enzyme_name, variable=var)
            cb.grid(row=row, column=0, sticky=tk.W, pady=2)
            
            recognition = enzyme_data['recognition']
            ttk.Label(enzyme_frame, text=recognition, 
                     font=('Courier', 9)).grid(row=row, column=1, sticky=tk.W, padx=10)
            row += 1
        
        # Show ladder option
        self.show_ladder_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(enzyme_frame, text="Show DNA Ladder",
                       variable=self.show_ladder_var).grid(
                           row=row, column=0, sticky=tk.W, pady=5)
        
        # Buttons
        button_frame = ttk.Frame(left_panel, padding="5")
        button_frame.grid(row=2, column=0, pady=5)
        
        ttk.Button(button_frame, text="Digest DNA",
                  command=self.digest_dna).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="Load Sample",
                  command=self.load_sample_sequence).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="Clear",
                  command=self.clear_all).grid(row=0, column=2, padx=5)
        
        # Results text
        results_frame = ttk.LabelFrame(left_panel, text="Digestion Results",
                                      padding="10")
        results_frame.grid(row=3, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        self.results_text = scrolledtext.ScrolledText(results_frame, height=12,
                                                      width=45,
                                                      font=('Courier', 8))
        self.results_text.grid(row=0, column=0)
        
        # Right panel - Gel visualization
        right_panel = ttk.Frame(self.root, padding="5")
        right_panel.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        gel_frame = ttk.LabelFrame(right_panel, text="Gel Electrophoresis",
                                  padding="10")
        gel_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.gel_canvas = GelElectrophoresisCanvas(gel_frame, width=500, height=600)
        self.gel_canvas.grid(row=0, column=0)
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.columnconfigure(1, weight=2)
        self.root.rowconfigure(1, weight=1)
        left_panel.rowconfigure(3, weight=1)
        right_panel.rowconfigure(0, weight=1)
        
        # Bind sequence text change
        self.seq_text.bind('<<Modified>>', self.update_sequence_info)
    
    def update_sequence_info(self, event=None):
        """Update sequence length display"""
        try:
            seq = self.seq_text.get("1.0", tk.END).strip()
            seq = seq.upper().replace(' ', '').replace('\n', '')
            length = len(seq)
            self.seq_info_label.config(text=f"Length: {length} bp")
            self.seq_text.edit_modified(False)
        except:
            pass
    
    def load_sample_sequence(self):
        """Load sample DNA sequence"""
        self.seq_text.delete("1.0", tk.END)
        self.seq_text.insert("1.0", SAMPLE_DNA)
        self.update_sequence_info()
        messagebox.showinfo("Sample Loaded",
                          f"Sample DNA sequence loaded!\n"
                          f"Source: E. coli lac operon region\n"
                          f"Length: {len(SAMPLE_DNA.replace(' ', '').replace(chr(10), ''))} bp")
    
    def clear_all(self):
        """Clear all fields"""
        self.seq_text.delete("1.0", tk.END)
        self.results_text.delete("1.0", tk.END)
        self.gel_canvas.delete('all')
        self.update_sequence_info()
    
    def digest_dna(self):
        """Perform digestion and display results"""
        # Get sequence
        seq = self.seq_text.get("1.0", tk.END).strip()
        if not seq:
            messagebox.showwarning("Warning", "Please enter a DNA sequence!")
            return
        
        # Get selected enzymes
        selected_enzymes = [name for name, var in self.enzyme_vars.items()
                          if var.get()]
        
        if not selected_enzymes:
            messagebox.showwarning("Warning",
                                 "Please select at least one enzyme!")
            return
        
        try:
            # Create simulator
            simulator = RestrictionEnzymeSimulator(seq)
            
            # Perform digestion
            results = simulator.digest(selected_enzymes)
            
            # Display text results
            self.display_text_results(results, len(simulator.dna_sequence))
            
            # Draw gel
            self.gel_canvas.draw_gel(results, self.show_ladder_var.get())
            
        except Exception as e:
            messagebox.showerror("Error", str(e))
    
    def display_text_results(self, results, seq_length):
        """Display digestion results as text"""
        self.results_text.delete("1.0", tk.END)
        
        output = "=" * 50 + "\n"
        output += "RESTRICTION DIGESTION RESULTS\n"
        output += "=" * 50 + "\n\n"
        output += f"DNA Sequence Length: {seq_length} bp\n"
        output += f"Enzymes Used: {len(results)}\n\n"
        
        for enzyme_name, data in results.items():
            output += "-" * 50 + "\n"
            output += f"Enzyme: {enzyme_name}\n"
            output += f"Recognition Site: {data['recognition']}\n"
            output += f"Number of Cleavages: {data['num_cuts']}\n"
            
            if data['cut_sites']:
                output += f"Cut Positions: {', '.join(map(str, data['cut_sites']))}\n"
            else:
                output += "Cut Positions: None\n"
            
            output += f"\nFragments ({len(data['fragments'])}):\n"
            for i, (start, end, length) in enumerate(data['fragments'], 1):
                output += f"  {i}. Position {start:5d}-{end:5d} | Length: {length:5d} bp\n"
            
            output += "\n"
        
        output += "=" * 50 + "\n"
        
        self.results_text.insert("1.0", output)


def main():
    """Main application entry point"""
    root = tk.Tk()
    app = RestrictionEnzymeGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
