Restriction Enzyme Digestion Simulator - Project L8
====================================================

Author: Iubitu Mara, 1241EA


Description:
------------
This application simulates DNA digestion by restriction enzymes and visualizes
the results using virtual gel electrophoresis. It accepts a DNA sequence and
shows where restriction enzymes cut, the resulting fragments, and displays
them on a simulated electrophoresis gel.


Features:
---------
✓ 5 Restriction Enzymes Implemented:
  - EcoRI:   Recognition: GAATTC, Cut: G^AATTC
  - BamHI:   Recognition: GGATCC, Cut: G^GATCC
  - HindIII: Recognition: AAGCTT, Cut: A^AGCTT
  - TaqI:    Recognition: TCGA,   Cut: T^CGA
  - HaeIII:  Recognition: GGCC,   Cut: GG^CC

✓ Input:
  - DNA sequence (100-10000 bp)
  - Selection of restriction enzymes to use
  - Option to show/hide DNA ladder

✓ Output:
  - Number of cleavages for each enzyme
  - Exact cleavage positions
  - Fragment lengths and positions
  - Visual gel electrophoresis simulation

✓ Gel Electrophoresis Visualization:
  - Realistic logarithmic migration (smaller fragments travel further)
  - DNA ladder with standard sizes (10kb to 250bp)
  - Color-coded bands
  - Fragment size labels
  - Multiple lanes for different enzymes


DNA Sequence Source:
--------------------
Sample DNA: E. coli lac operon region
Source: NCBI (National Center for Biotechnology Information)
Length: ~1500 base pairs
Accession: Partial sequence from E. coli lactose operon

The sample sequence contains multiple restriction sites for demonstration.


How to Run:
-----------
1. Make sure Python 3.x is installed
2. Run the application:
   python L8.py

3. The sample DNA sequence loads automatically, or enter your own:
   - Paste DNA sequence (ATCG only)
   - Minimum 100 bp, maximum 10000 bp
   - Spaces and newlines are automatically removed

4. Select enzymes:
   - Check/uncheck enzymes to use
   - At least one enzyme must be selected

5. Click "Digest DNA" to run the simulation

6. Results display:
   - Left panel: Detailed text results
     * Number of cuts per enzyme
     * Exact cut positions
     * Fragment sizes and positions
   
   - Right panel: Gel electrophoresis visualization
     * Ladder lane (if enabled)
     * One lane per enzyme
     * Bands show fragment migration
     * Size labels on bands


Understanding the Results:
--------------------------
Text Results:
- Shows each enzyme's recognition site
- Lists number of cleavages
- Shows exact positions where DNA was cut
- Lists all fragments with their positions and lengths

Gel Visualization:
- Bands higher on gel = larger fragments (slower migration)
- Bands lower on gel = smaller fragments (faster migration)
- Band brightness indicates relative amount
- Compare with ladder to estimate fragment sizes


Restriction Enzyme Details:
---------------------------
Each enzyme recognizes a specific DNA sequence and cuts at a specific position:

EcoRI:
  Recognition: 5'-GAATTC-3'
  Cleavage:    5'---G     AATTC---3'
               3'---CTTAA     G---5'
  (Creates sticky ends with 5' overhang)

BamHI:
  Recognition: 5'-GGATCC-3'
  Cleavage:    5'---G     GATCC---3'
               3'---CCTAG     G---5'
  (Creates sticky ends with 5' overhang)

HindIII:
  Recognition: 5'-AAGCTT-3'
  Cleavage:    5'---A     AGCTT---3'
               3'---TTCGA     A---5'
  (Creates sticky ends with 5' overhang)

TaqI:
  Recognition: 5'-TCGA-3'
  Cleavage:    5'---T   CGA---3'
               3'---AGC   T---5'
  (Creates sticky ends with 5' overhang)

HaeIII:
  Recognition: 5'-GGCC-3'
  Cleavage:    5'---GG  CC---3'
               3'---CC  GG---5'
  (Creates blunt ends)


Scientific Background:
----------------------
Restriction enzymes (restriction endonucleases) are proteins that cut DNA
at specific recognition sequences. They are:

- Molecular scissors used in molecular biology
- Isolated from bacteria (defense against viruses)
- Essential tools for DNA cloning, mapping, and analysis
- Named after the bacteria they come from
  (e.g., EcoRI from E. coli strain R)

Gel Electrophoresis:
- Technique to separate DNA fragments by size
- DNA is negatively charged, moves toward positive electrode
- Smaller fragments move faster through gel matrix
- Results in band pattern showing fragment sizes
- Used for DNA fingerprinting, cloning verification, etc.


Technical Details:
------------------
Programming Language: Python 3.x
GUI Framework: Tkinter (included with Python)
Dependencies: None (uses only standard library)

Key Components:
- RestrictionEnzymeSimulator: Core digestion logic
- GelElectrophoresisCanvas: Gel visualization
- RestrictionEnzymeGUI: User interface

Algorithms:
- Pattern matching for recognition site detection
- Fragment calculation from cut positions
- Logarithmic migration simulation for gel display


Requirements:
-------------
- Python 3.6 or higher
- Tkinter (usually included with Python)
- Display capable of 900x800 resolution


Example Use Cases:
------------------
1. Planning molecular cloning experiments
2. DNA mapping and analysis
3. Predicting restriction digest patterns
4. Educational demonstrations of restriction enzymes
5. Comparing different enzyme combinations


Buttons:
--------
- "Digest DNA": Performs digestion simulation
- "Load Sample": Loads example E. coli sequence
- "Clear": Clears all input and results


Troubleshooting:
----------------
Problem: "Invalid DNA sequence"
Solution: Only use A, T, C, G characters

Problem: "DNA sequence too short"
Solution: Enter at least 100 base pairs

Problem: "Please select at least one enzyme"
Solution: Check at least one enzyme checkbox

Problem: Gel doesn't show
Solution: Click "Digest DNA" after entering sequence


References:
-----------
- NCBI: https://www.ncbi.nlm.nih.gov/
- Restriction enzymes: New England Biolabs (NEB)
- Example implementations:
  * http://www.endmemo.com/bio/egel.php
  * http://www.restrictionmapper.org/


Version History:
----------------
v1.0 - Initial release
  - 5 restriction enzymes
  - Gel electrophoresis visualization
  - DNA ladder support
  - Detailed results output


================================================================================
Project completed as part of Bioinformatics course requirements
================================================================================
