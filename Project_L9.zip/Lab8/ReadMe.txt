Author: Iubitu Mara, 1241EA

Lab 8: Transposable Element Detection

This lab implements software applications for detecting transposable elements (TEs) in DNA sequences, analyzing their positions, and identifying overlapping/intersecting scenarios.

Files:

1. ex1.py - Basic Transposable Element Detection
   - Creates artificial DNA sequence (200-400 bases)
   - Simulates 3-4 transposable elements with predefined sequences
   - Detects and reports positions (start, end) of all TEs
   - Analyzes three intersection cases:
     * TE completely inside another TE
     * TE starts inside and ends outside another TE
     * TEs that are separate (non-overlapping)
   - Screenshot: ex1.png

2. ex2.py - Advanced Overlap Analysis
   - Generates artificial DNA sequence with inserted TEs
   - Implements comprehensive overlap detection algorithm
   - Identifies and reports all types of TE overlaps:
     * Complete containment (one TE inside another)
     * Partial overlap (intersecting boundaries)
   - Ensures non-overlapping insertion during sequence creation
   - Screenshot: ex2.png

3. ex3.py - NCBI Genome Analysis for Inverted Repeats
   - Downloads 3 bacterial genomes from NCBI:
     * E. coli MG1655 (NC_000913.3)
     * B. subtilis 168 (NC_000964.3)
     * P. aeruginosa PAO1 (NC_002516.2)
   - Detects inverted repeats (4-6 bp) as potential transposon markers
   - Uses reverse complement matching
   - Reports positions and spacer distances
   - Requires BioPython library
   - Screenshots: ex3-1.png, ex3-2.png

Dependencies:
- Python 3.x
- BioPython (for ex3.py only): pip install biopython

Usage:
  python ex1.py
  python ex2.py
  python ex3.py

Note: Inverted repeats often mark transposable element boundaries in bacterial genomes.